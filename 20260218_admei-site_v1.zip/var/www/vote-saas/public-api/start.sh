#!/bin/bash
cd /var/www/vote-saas/public-api
pm2 start server.js --name public-api
