const express = require('express');
const mysql = require('mysql2/promise');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.json());

// 调试日志
app.use((req, res, next) => {
  console.log(`[${new Date().toISOString()}] ${req.method} ${req.path}`);
  next();
});

const pool = mysql.createPool({
  host: '127.0.0.1',
  user: 'root',
  password: 'root123',
  database: 'vote_saas',
  waitForConnections: true,
  connectionLimit: 10
});

// JWT解析（简化版）
function decodeToken(token) {
  try {
    const parts = token.split('.');
    if (parts.length !== 3) return null;
    return JSON.parse(Buffer.from(parts[1], 'base64').toString());
  } catch (e) {
    return null;
  }
}

// === 公开API ===

// 商户列表
app.get('/merchants', async (req, res) => {
  try {
    const [rows] = await pool.query(`
      SELECT id, shop_name_zh as shopNameZh, shop_name_en as shopNameEn, 
             logo, banner, invite_code as inviteCode, status
      FROM t_merchant WHERE status = 1 AND deleted = 0
    `);
    res.json(rows);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// 平台配置
app.get('/platform-config', async (req, res) => {
  try {
    const [rows] = await pool.query(`SELECT * FROM t_platform_config WHERE config_key = 'platform.locale' LIMIT 1`);
    res.json({
      locale: rows[0]?.config_value || 'zh-CN,en-US',
      platformName: '私域商城',
      platformNameEn: 'Private Mall'
    });
  } catch (error) {
    res.json({ locale: 'zh-CN,en-US', platformName: '私域商城', platformNameEn: 'Private Mall' });
  }
});

// === 用户端API ===

// 用户可用的商家列表（未绑定或可换绑）
app.get('/user/merchants', async (req, res) => {
  try {
    const token = req.headers.authorization?.replace('Bearer ', '');
    if (!token) return res.status(401).json({ message: 'Unauthorized' });
    
    const decoded = decodeToken(token);
    if (!decoded) return res.status(401).json({ message: 'Invalid token' });
    
    // 获取所有可用商家（排除已绑定的）
    const [rows] = await pool.query(`
      SELECT id, shop_name_zh as shopNameZh, shop_name_en as shopNameEn, 
             logo, banner, invite_code as inviteCode, status
      FROM t_merchant WHERE status = 1 AND deleted = 0
    `);
    res.json(rows);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// === 商户端API ===

// 商户统计
app.get('/merchant/stats', async (req, res) => {
  try {
    const token = req.headers.authorization?.replace('Bearer ', '');
    if (!token) return res.status(401).json({ message: 'Unauthorized' });
    
    const decoded = decodeToken(token);
    if (!decoded || !decoded.merchantId) return res.status(401).json({ message: 'Invalid token' });
    
    const merchantId = decoded.merchantId;
    
    const [[{ totalProducts }]] = await pool.query(
      'SELECT COUNT(*) as totalProducts FROM t_product WHERE merchant_id = ? AND deleted = 0',
      [merchantId]
    );
    
    const [[{ totalOrders }]] = await pool.query(
      'SELECT COUNT(*) as totalOrders FROM t_order WHERE merchant_id = ? AND deleted = 0',
      [merchantId]
    );
    
    const [[{ todayOrders }]] = await pool.query(
      `SELECT COUNT(*) as todayOrders FROM t_order WHERE merchant_id = ? AND deleted = 0 AND DATE(created_at) = CURDATE()`,
      [merchantId]
    );
    
    const [[{ totalSales }]] = await pool.query(
      'SELECT COALESCE(SUM(total_amount), 0) as totalSales FROM t_order WHERE merchant_id = ? AND deleted = 0 AND status != "CANCELLED"',
      [merchantId]
    );
    
    const [[{ todaySales }]] = await pool.query(
      `SELECT COALESCE(SUM(total_amount), 0) as todaySales FROM t_order WHERE merchant_id = ? AND deleted = 0 AND status != "CANCELLED" AND DATE(created_at) = CURDATE()`,
      [merchantId]
    );
    
    res.json({ totalProducts, totalOrders, todayOrders, totalSales, todaySales });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// 商户确认订单
app.put('/merchant/orders/:id/confirm', async (req, res) => {
  try {
    const token = req.headers.authorization?.replace('Bearer ', '');
    if (!token) return res.status(401).json({ message: 'Unauthorized' });
    
    const decoded = decodeToken(token);
    if (!decoded || !decoded.merchantId) return res.status(401).json({ message: 'Invalid token' });
    
    const orderId = req.params.id;
    const merchantId = decoded.merchantId;
    
    await pool.query(
      `UPDATE t_order SET status = 'CONFIRMED', confirmed_at = NOW() 
       WHERE id = ? AND merchant_id = ? AND status = 'PENDING'`,
      [orderId, merchantId]
    );
    
    res.json({ message: '订单已确认' });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// 商户发货
app.put('/merchant/orders/:id/ship', async (req, res) => {
  try {
    const token = req.headers.authorization?.replace('Bearer ', '');
    if (!token) return res.status(401).json({ message: 'Unauthorized' });
    
    const decoded = decodeToken(token);
    if (!decoded || !decoded.merchantId) return res.status(401).json({ message: 'Invalid token' });
    
    const orderId = req.params.id;
    const merchantId = decoded.merchantId;
    
    await pool.query(
      `UPDATE t_order SET status = 'SHIPPED', shipped_at = NOW() 
       WHERE id = ? AND merchant_id = ? AND status = 'CONFIRMED'`,
      [orderId, merchantId]
    );
    
    res.json({ message: '订单已发货' });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// 商户完成订单
app.put('/merchant/orders/:id/complete', async (req, res) => {
  try {
    const token = req.headers.authorization?.replace('Bearer ', '');
    if (!token) return res.status(401).json({ message: 'Unauthorized' });
    
    const decoded = decodeToken(token);
    if (!decoded || !decoded.merchantId) return res.status(401).json({ message: 'Invalid token' });
    
    const orderId = req.params.id;
    const merchantId = decoded.merchantId;
    
    await pool.query(
      `UPDATE t_order SET status = 'COMPLETED', completed_at = NOW() 
       WHERE id = ? AND merchant_id = ? AND status = 'SHIPPED'`,
      [orderId, merchantId]
    );
    
    res.json({ message: '订单已完成' });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// 商户取消订单
app.put('/merchant/orders/:id/cancel', async (req, res) => {
  try {
    const token = req.headers.authorization?.replace('Bearer ', '');
    if (!token) return res.status(401).json({ message: 'Unauthorized' });
    
    const decoded = decodeToken(token);
    if (!decoded || !decoded.merchantId) return res.status(401).json({ message: 'Invalid token' });
    
    const orderId = req.params.id;
    const merchantId = decoded.merchantId;
    const { reason } = req.body;
    
    await pool.query(
      `UPDATE t_order SET status = 'CANCELLED', cancelled_at = NOW(), cancel_reason = ? 
       WHERE id = ? AND merchant_id = ? AND status IN ('PENDING', 'CONFIRMED')`,
      [reason || '商户取消', orderId, merchantId]
    );
    
    res.json({ message: '订单已取消' });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// === 管理端API ===

// 管理员统计
app.get('/admin/stats', async (req, res) => {
  try {
    const token = req.headers.authorization?.replace('Bearer ', '');
    if (!token) return res.status(401).json({ message: 'Unauthorized' });
    
    const [[{ totalMerchants }]] = await pool.query('SELECT COUNT(*) as totalMerchants FROM t_merchant WHERE deleted = 0');
    const [[{ totalUsers }]] = await pool.query('SELECT COUNT(*) as totalUsers FROM t_user WHERE deleted = 0');
    const [[{ totalOrders }]] = await pool.query('SELECT COUNT(*) as totalOrders FROM t_order WHERE deleted = 0');
    const [[{ todayOrders }]] = await pool.query(`SELECT COUNT(*) as todayOrders FROM t_order WHERE deleted = 0 AND DATE(created_at) = CURDATE()`);
    
    res.json({ totalMerchants, totalUsers, totalOrders, todayOrders });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// 管理员用户列表
app.get('/admin/users', async (req, res) => {
  try {
    const token = req.headers.authorization?.replace('Bearer ', '');
    if (!token) return res.status(401).json({ message: 'Unauthorized' });
    
    const page = parseInt(req.query.page) || 1;
    const size = parseInt(req.query.size) || 10;
    const offset = (page - 1) * size;
    
    const [rows] = await pool.query(`
      SELECT id, username, phone, email, merchant_id as merchantId, status, created_at as createdAt
      FROM t_user WHERE deleted = 0 ORDER BY id DESC LIMIT ? OFFSET ?
    `, [size, offset]);
    
    const [[{ total }]] = await pool.query('SELECT COUNT(*) as total FROM t_user WHERE deleted = 0');
    
    res.json({ records: rows, total, size, current: page, pages: Math.ceil(total / size) });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

const PORT = 8081;
app.listen(PORT, '127.0.0.1', () => {
  console.log(`Public API running on port ${PORT}`);
});
