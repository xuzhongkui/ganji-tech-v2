#!/bin/bash
pkill -f vote-0.0.1-SNAPSHOT.jar || true
sleep 2

cd /var/www/vote-saas

nohup java -jar vote-0.0.1-SNAPSHOT.jar \
  --server.port=8080 \
  --spring.datasource.url=jdbc:mysql://127.0.0.1:3306/vote_saas \
  --spring.datasource.username=root \
  --spring.datasource.password=root123 \
  --app.base-url=https://admei.site \
  --spring.mail.host=hwsmtp.exmail.qq.com \
  --spring.mail.port=465 \
  --spring.mail.username=zk@admei.net \
  --spring.mail.password=Tido@1234 \
  --spring.mail.properties.mail.smtp.auth=true \
  --spring.mail.properties.mail.smtp.starttls.enable=true \
  --spring.mail.properties.mail.smtp.starttls.required=true \
  --spring.mail.default-encoding=UTF-8 \
  > logs/app.log 2>&1 &

echo "Started with all configurations"
