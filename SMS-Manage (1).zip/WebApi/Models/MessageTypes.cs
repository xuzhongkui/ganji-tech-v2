namespace WebApi.Models;

public static class MessageTypes
{
    public const string Sms = "Sms";
    public const string Hangup = "Hangup";
}
