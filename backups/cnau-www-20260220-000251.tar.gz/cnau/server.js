const express = require('express');
const mysql = require('mysql2/promise');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const cors = require('cors');

const app = express();
app.use(express.json());
app.use(cors());

const pool = mysql.createPool({
  host: 'localhost',
  user: 'root',
  password: 'root123',
  database: 'cnau',
  waitForConnections: true,
  connectionLimit: 10
});

const SECRET = 'cnau_secret_2026';

// 用户注册
app.post('/api/user/register', async (req, res) => {
  const { phone, password, username } = req.body;
  try {
    const [exist] = await pool.execute('SELECT id FROM t_user WHERE phone = ?', [phone]);
    if (exist.length > 0) return res.json({ success: false, message: '手机号已注册' });
    const hashedPassword = await bcrypt.hash(password, 10);
    const [result] = await pool.execute('INSERT INTO t_user (username, phone, password) VALUES (?, ?, ?)', [username || phone, phone, hashedPassword]);
    res.json({ success: true, message: '注册成功', userId: result.insertId });
  } catch (e) { res.json({ success: false, message: e.message }); }
});

// 用户登录
app.post('/api/user/login', async (req, res) => {
  const { phone, password } = req.body;
  try {
    const [users] = await pool.execute('SELECT * FROM t_user WHERE phone = ?', [phone]);
    if (users.length === 0) return res.json({ success: false, message: '用户不存在' });
    const user = users[0];
    const isValid = bcrypt.compareSync(password, user.password);
    if (!isValid) return res.json({ success: false, message: '密码错误' });
    const token = jwt.sign({ userId: user.id, type: 'user' }, SECRET, { expiresIn: '7d' });
    res.json({ success: true, token, user: { id: user.id, username: user.username, phone: user.phone } });
  } catch (e) { res.json({ success: false, message: e.message }); }
});

// 师傅注册
app.post('/api/master/register', async (req, res) => {
  const { phone, password, realName, wechat, serviceTypes, description, priceRange } = req.body;
  try {
    let userId;
    const [exist] = await pool.execute('SELECT id FROM t_user WHERE phone = ?', [phone]);
    if (exist.length > 0) { userId = exist[0].id; }
    else {
      const hashedPassword = await bcrypt.hash(password, 10);
      const [result] = await pool.execute('INSERT INTO t_user (username, phone, password) VALUES (?, ?, ?)', [realName, phone, hashedPassword]);
      userId = result.insertId;
    }
    const [result] = await pool.execute('INSERT INTO t_master (user_id, real_name, wechat, service_types, description, price_range, status) VALUES (?, ?, ?, ?, ?, ?, 0)', [userId, realName, wechat || '', serviceTypes || '', description || '', priceRange || '']);
    res.json({ success: true, message: '申请已提交，等待审核', masterId: result.insertId });
  } catch (e) { res.json({ success: false, message: e.message }); }
});

// 师傅登录
app.post('/api/master/login', async (req, res) => {
  const { phone, password } = req.body;
  try {
    const [users] = await pool.execute('SELECT * FROM t_user WHERE phone = ?', [phone]);
    if (users.length === 0) return res.json({ success: false, message: '用户不存在' });
    const user = users[0];
    const isValid = bcrypt.compareSync(password, user.password);
    if (!isValid) return res.json({ success: false, message: '密码错误' });
    const [masters] = await pool.execute('SELECT * FROM t_master WHERE user_id = ?', [user.id]);
    if (masters.length === 0) return res.json({ success: false, message: '您还不是师傅' });
    if (masters[0].status !== 1) return res.json({ success: false, message: '账号还在审核中' });
    const token = jwt.sign({ userId: user.id, masterId: masters[0].id, type: 'master' }, SECRET, { expiresIn: '7d' });
    res.json({ success: true, token, master: masters[0] });
  } catch (e) { res.json({ success: false, message: e.message }); }
});

// 师傅列表
app.get('/api/master/list', async (req, res) => {
  try {
    const { type } = req.query;
    let sql = 'SELECT id, real_name, wechat, service_types, description, price_range, rating, order_count FROM t_master WHERE status = 1';
    if (type) sql += ' AND service_types LIKE ?';
    sql += ' ORDER BY rating DESC, order_count DESC LIMIT 50';
    const [masters] = await pool.execute(sql, type ? [`%${type}%`] : []);
    res.json({ success: true, masters });
  } catch (e) { res.json({ success: false, message: e.message }); }
});

// 创建订单
app.post('/api/order/create', async (req, res) => {
  const { userId, masterId, serviceType, serviceContent, address, phone, appointmentTime, price } = req.body;
  try {
    const orderNo = 'CN' + Date.now() + Math.random().toString(36).substr(2, 4).toUpperCase();
    await pool.execute('INSERT INTO t_order (order_no, user_id, master_id, service_type, service_content, address, phone, appointment_time, price, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 0)', [orderNo, userId, masterId, serviceType, serviceContent, address, phone, appointmentTime || null, price || 0]);
    res.json({ success: true, message: '预约成功', orderNo });
  } catch (e) { res.json({ success: false, message: e.message }); }
});

// 订单列表
app.get('/api/order/list', async (req, res) => {
  try {
    const { userId, masterId } = req.query;
    let sql = 'SELECT o.*, m.real_name as master_name, m.wechat as master_wechat FROM t_order o LEFT JOIN t_master m ON o.master_id = m.id WHERE 1=1';
    if (userId) sql += ' AND o.user_id = ?';
    if (masterId) sql += ' AND o.master_id = ?';
    sql += ' ORDER BY o.created_at DESC';
    const [orders] = await pool.execute(sql, userId ? [userId] : masterId ? [masterId] : []);
    res.json({ success: true, orders });
  } catch (e) { res.json({ success: false, message: e.message }); }
});

// 接单
app.post('/api/order/accept', async (req, res) => {
  const { orderId } = req.body;
  try {
    await pool.execute('UPDATE t_order SET status = 1 WHERE id = ?', [orderId]);
    res.json({ success: true, message: '接单成功' });
  } catch (e) { res.json({ success: false, message: e.message }); }
});

// 拒绝订单
app.post('/api/order/reject', async (req, res) => {
  const { orderId } = req.body;
  try {
    await pool.execute('UPDATE t_order SET status = 4 WHERE id = ?', [orderId]);
    res.json({ success: true, message: '已拒绝' });
  } catch (e) { res.json({ success: false, message: e.message }); }
});

// 完成订单
app.post('/api/order/complete', async (req, res) => {
  const { orderId } = req.body;
  try {
    await pool.execute('UPDATE t_order SET status = 3 WHERE id = ?', [orderId]);
    res.json({ success: true, message: '已完成' });
  } catch (e) { res.json({ success: false, message: e.message }); }
});

// 统计
app.get('/api/admin/stats', async (req, res) => {
  try {
    const [u] = await pool.execute('SELECT COUNT(*) as c FROM t_user');
    const [m] = await pool.execute('SELECT COUNT(*) as c FROM t_master WHERE status = 1');
    const [o] = await pool.execute('SELECT COUNT(*) as c FROM t_order');
    res.json({ success: true, stats: { users: u[0].c, masters: m[0].c, orders: o[0].c }});
  } catch (e) { res.json({ success: false, message: e.message }); }
});

// 师傅列表(管理)
app.get('/api/admin/master/list', async (req, res) => {
  try {
    const { status } = req.query;
    let sql = 'SELECT m.*, u.phone FROM t_master m LEFT JOIN t_user u ON m.user_id = u.id';
    if (status !== undefined) sql += ' WHERE m.status = ?';
    sql += ' ORDER BY m.created_at DESC';
    const [masters] = await pool.execute(sql, status !== undefined ? [status] : []);
    res.json({ success: true, masters });
  } catch (e) { res.json({ success: false, message: e.message }); }
});

// 审核师傅
app.put('/api/admin/master/audit', async (req, res) => {
  const { masterId, status } = req.body;
  try {
    await pool.execute('UPDATE t_master SET status = ? WHERE id = ?', [status, masterId]);
    res.json({ success: true, message: status === 1 ? '审核通过' : '已拒绝' });
  } catch (e) { res.json({ success: false, message: e.message }); }
});

app.listen(3000, () => console.log('华人帮API: http://localhost:3000'));

// 二手商品列表
app.get('/api/secondhand/list', async (req, res) => {
  try {
    const [items] = await pool.execute('SELECT * FROM t_secondhand WHERE status = 1 ORDER BY created_at DESC LIMIT 100');
    res.json({ success: true, items });
  } catch (e) { res.json({ success: false, message: e.message }); }
});

// 师傅详情
app.get('/api/master/:id', async (req, res) => {
  try {
    const [masters] = await pool.execute('SELECT id, real_name, wechat, service_types, description, price_range, rating, order_count FROM t_master WHERE id = ? AND status = 1', [req.params.id]);
    if (masters.length === 0) return res.json({ success: false, message: '师傅不存在' });
    res.json({ success: true, master: masters[0] });
  } catch (e) { res.json({ success: false, message: e.message }); }
});
