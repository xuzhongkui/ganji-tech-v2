const express = require('express');
// ============================================
// API注册表 (防止重复添加)
// ============================================
const registeredApis = new Set();

// 安全注册API - 防止重复
function registerApi(method, path, handler) {
  const key = method + ':' + path;
  if (registeredApis.has(key)) {
    console.log('[API] Skipping duplicate: ' + key);
    return;
  }
  registeredApis.add(key);
  if (method === 'GET') app.get(path, handler);
  else if (method === 'POST') app.post(path, handler);
  else if (method === 'PUT') app.put(path, handler);
  else if (method === 'DELETE') app.delete(path, handler);
}

// 已注册API索引:
// 用户: /api/user/register, /api/user/login, /api/user/info, /api/user/change-password
// 师傅: /api/master/register, /api/master/login, /api/master/list, /api/master/:id, /api/master/cases, /api/master/top, /api/master/top-list, /api/master/schedule
// 订单: /api/order/create, /api/order/list, /api/order/:id, /api/order/accept, /api/order/reject, /api/order/complete, /api/order/cancel
// 评价: /api/review/create, /api/review/list, /api/review/reply
// 通知: /api/notification/list, /api/notification/read, /api/notification/unread
// 二手: /api/secondhand/list, /api/secondhand/:id, /api/secondhand/create, /api/secondhand/:id (put), /api/secondhand/:id (delete)
// 合伙: /api/partnership/agreement, /api/partnership/sign, /api/partnership/status
// 收藏: /api/favorite/add, /api/favorite/remove, /api/favorite/list, /api/favorite/check
// 优惠券: /api/coupon/create, /api/coupon/claim, /api/coupon/my, /api/coupon/use
// 搜索: /api/search
// 管理后台: /api/admin/* (见下方)

// ============================================
// 用户API
// ============================================


const multer = require('multer');
const fs = require('fs');
const mysql = require('mysql2/promise');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const cors = require('cors');

const app = express();
app.use(express.json());
app.use(cors());

const pool = mysql.createPool({
  host: 'localhost',
  user: 'root',
  password: 'root123',
  database: 'cnau',
  waitForConnections: true,
  connectionLimit: 10
});

const SECRET = 'cnau_secret_2026';

// ============ 用户模块 ============

// 用户注册
app.post('/api/user/register', async (req, res) => {
  const { phone, password, username } = req.body;
  try {
    const [exist] = await pool.execute('SELECT id FROM t_user WHERE phone = ?', [phone]);
    if (exist.length > 0) return res.json({ success: false, message: '手机号已注册' });
    const hashedPassword = await bcrypt.hash(password, 10);
    const [result] = await pool.execute('INSERT INTO t_user (username, phone, password) VALUES (?, ?, ?)', [username || phone, phone, hashedPassword]);
    res.json({ success: true, message: '注册成功', userId: result.insertId });
  } catch (e) { res.json({ success: false, message: e.message }); }
});

// 用户登录
app.post('/api/user/login', async (req, res) => {
  const { phone, password } = req.body;
  try {
    const [users] = await pool.execute('SELECT * FROM t_user WHERE phone = ?', [phone]);
    if (users.length === 0) return res.json({ success: false, message: '用户不存在' });
    const user = users[0];
    const isValid = bcrypt.compareSync(password, user.password);
    if (!isValid) return res.json({ success: false, message: '密码错误' });
    const token = jwt.sign({ userId: user.id, type: 'user' }, SECRET, { expiresIn: '7d' });
    res.json({ success: true, token, user: { id: user.id, username: user.username, phone: user.phone } });
  } catch (e) { res.json({ success: false, message: e.message }); }
});

// 获取用户信息
app.get('/api/user/info', async (req, res) => {
  const token = req.headers.authorization;
  if (!token) return res.json({ success: false, message: '未登录' });
  try {
    const decoded = jwt.verify(token.replace('Bearer ', ''), SECRET);
    const [users] = await pool.execute('SELECT id, username, phone, email, avatar, wechat FROM t_user WHERE id = ?', [decoded.userId]);
    if (users.length === 0) return res.json({ success: false, message: '用户不存在' });
    res.json({ success: true, user: users[0] });
  } catch (e) { res.json({ success: false, message: e.message }); }
});

// ============ 师傅模块 ============

// 师傅注册
app.post('/api/master/register', async (req, res) => {
  const { phone, password, realName, wechat, serviceTypes, description, priceRange } = req.body;
  try {
    // 检查服务类型是否已满
    if (serviceTypes) {
      const types = serviceTypes.split(',');
      for (const type of types) {
        const [cat] = await pool.execute(
          'SELECT name, max_master, (SELECT COUNT(*) FROM t_master WHERE service_types LIKE ? AND status = 1) as current FROM t_service_category WHERE name_en = ? OR name = ?',
          [`%${type.trim()}%`, type.trim(), type.trim()]
        );
        if (cat.length > 0 && cat[0].max_master > 0 && cat[0].current >= cat[0].max_master) {
          return res.json({ success: false, message: `${cat[0].name}类别师傅已满员（${cat[0].max_master}名），暂时无法入驻，请选择其他类别` });
        }
      }
    }
    
    let userId;
    const [exist] = await pool.execute('SELECT id FROM t_user WHERE phone = ?', [phone]);
    if (exist.length > 0) { userId = exist[0].id; }
    else {
      const hashedPassword = await bcrypt.hash(password, 10);
      const [result] = await pool.execute('INSERT INTO t_user (username, phone, password) VALUES (?, ?, ?)', [realName, phone, hashedPassword]);
      userId = result.insertId;
    }
    const [result] = await pool.execute('INSERT INTO t_master (user_id, real_name, wechat, service_types, description, price_range, status) VALUES (?, ?, ?, ?, ?, ?, 0)', [userId, realName, wechat || '', serviceTypes || '', description || '', priceRange || '']);
    res.json({ success: true, message: '申请已提交，等待审核', masterId: result.insertId });
  } catch (e) { res.json({ success: false, message: e.message }); }
});

// 师傅登录
app.post('/api/master/login', async (req, res) => {
  const { phone, password } = req.body;
  try {
    const [users] = await pool.execute('SELECT * FROM t_user WHERE phone = ?', [phone]);
    if (users.length === 0) return res.json({ success: false, message: '用户不存在' });
    const user = users[0];
    const isValid = bcrypt.compareSync(password, user.password);
    if (!isValid) return res.json({ success: false, message: '密码错误' });
    const [masters] = await pool.execute('SELECT * FROM t_master WHERE user_id = ?', [user.id]);
    if (masters.length === 0) return res.json({ success: false, message: '您还不是师傅' });
    if (masters[0].status !== 1) return res.json({ success: false, message: '账号还在审核中' });
    const token = jwt.sign({ userId: user.id, masterId: masters[0].id, type: 'master' }, SECRET, { expiresIn: '7d' });
    res.json({ success: true, token, master: masters[0] });
  } catch (e) { res.json({ success: false, message: e.message }); }
});

// 师傅列表
app.get('/api/master/list', async (req, res) => {
  try {
    const { type, keyword } = req.query;
    let sql = 'SELECT id, real_name, wechat, service_types, description, price_range, rating, order_count FROM t_master WHERE status = 1';
    const params = [];
    if (type) { sql += ' AND service_types LIKE ?'; params.push(`%${type}%`); }
    if (keyword) { sql += ' AND (real_name LIKE ? OR service_types LIKE ?)'; params.push(`%${keyword}%`, `%${keyword}%`); }
    sql += ' ORDER BY is_top DESC, rating DESC, order_count DESC LIMIT 50';
    const [masters] = await pool.execute(sql, params);
    res.json({ success: true, masters });
  } catch (e) { res.json({ success: false, message: e.message }); }
});

// 师傅详情
app.get('\/api\/master\/cases', async (req, res) => {
  const { masterId } = req.query;
  try {
    const [cases] = await pool.execute('SELECT * FROM t_master_case WHERE master_id = ? ORDER BY created_at DESC', [masterId]);
    res.json({ success: true, cases });
  } catch (e) { res.json({ success: false, message: e.message }); }
});

app.get('/api/master/cases', async (req, res) => {
  const { masterId } = req.query;
  try {
    const [cases] = await pool.execute('SELECT * FROM t_master_case WHERE master_id = ? ORDER BY created_at DESC', [masterId]);
    res.json({ success: true, cases });
  } catch (e) { res.json({ success: false, message: e.message }); }
});
app.get('/api/master/:id', async (req, res) => {
  try {
    const [masters] = await pool.execute('SELECT id, real_name, wechat, service_types, description, price_range, rating, order_count FROM t_master WHERE id = ? AND status = 1', [req.params.id]);
    if (masters.length === 0) return res.json({ success: false, message: '师傅不存在' });
    
    // 获取师傅评价
    const [reviews] = await pool.execute(`
      SELECT r.*, u.username 
      FROM t_review r 
      LEFT JOIN t_user u ON r.user_id = u.id 
      WHERE r.master_id = ? AND r.status = 1 
      ORDER BY r.created_at DESC LIMIT 10
    `, [req.params.id]);
    
    res.json({ success: true, master: masters[0], reviews });
  } catch (e) { res.json({ success: false, message: e.message }); }
});

// ============ 订单模块 ============

// 创建订单
app.post('/api/order/create', async (req, res) => {
  const { userId, masterId, serviceType, serviceContent, address, phone, appointmentTime, price } = req.body;
  try {
    const orderNo = 'CN' + Date.now() + Math.random().toString(36).substr(2, 4).toUpperCase();
    await pool.execute('INSERT INTO t_order (order_no, user_id, master_id, service_type, service_content, address, phone, appointment_time, price, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 0)', [orderNo, userId, masterId, serviceType, serviceContent, address, phone, appointmentTime || null, price || 0]);
    
    // 创建通知
    const [master] = await pool.execute('SELECT user_id FROM t_master WHERE id = ?', [masterId]);
    if (master.length > 0) {
      await pool.execute('INSERT INTO t_notification (user_id, type, title, content, data) VALUES (?, ?, ?, ?, ?)', 
        [master[0].user_id, 'order', '新订单通知', '您有一个新订单，请及时查看', JSON.stringify({ orderNo })]);
    }
    
    res.json({ success: true, message: '预约成功', orderNo });
  } catch (e) { res.json({ success: false, message: e.message }); }
});

// 订单列表
app.get('/api/order/list', async (req, res) => {
  try {
    const { userId, masterId } = req.query;
    let sql = 'SELECT o.*, m.real_name as master_name, m.wechat as master_wechat FROM t_order o LEFT JOIN t_master m ON o.master_id = m.id WHERE 1=1';
    const params = [];
    if (userId) { sql += ' AND o.user_id = ?'; params.push(userId); }
    if (masterId) { sql += ' AND o.master_id = ?'; params.push(masterId); }
    sql += ' ORDER BY o.created_at DESC';
    const [orders] = await pool.execute(sql, params);
    res.json({ success: true, orders });
  } catch (e) { res.json({ success: false, message: e.message }); }
});

// 订单详情
app.get('/api/order/:id', async (req, res) => {
  try {
    const [orders] = await pool.execute(`
      SELECT o.*, m.real_name as master_name, m.wechat as master_wechat,
             u.username as user_name, u.phone as user_phone
      FROM t_order o 
      LEFT JOIN t_master m ON o.master_id = m.id 
      LEFT JOIN t_user u ON o.user_id = u.id
      WHERE o.id = ?
    `, [req.params.id]);
    if (orders.length === 0) return res.json({ success: false, message: '订单不存在' });
    res.json({ success: true, order: orders[0] });
  } catch (e) { res.json({ success: false, message: e.message }); }
});

// 接单
app.post('/api/order/accept', async (req, res) => {
  const { orderId, masterId } = req.body;
  try {
    await pool.execute('UPDATE t_order SET status = 1 WHERE id = ?', [orderId]);
    
    // 通知用户
    const [order] = await pool.execute('SELECT user_id FROM t_order WHERE id = ?', [orderId]);
    if (order.length > 0) {
      await pool.execute('INSERT INTO t_notification (user_id, type, title, content, data) VALUES (?, ?, ?, ?, ?)', 
        [order[0].user_id, 'order', '订单已接单', '师傅已接单，请等待服务', JSON.stringify({ orderId })]);
    }
    
    res.json({ success: true, message: '接单成功' });
  } catch (e) { res.json({ success: false, message: e.message }); }
});

// 拒绝订单
app.post('/api/order/reject', async (req, res) => {
  const { orderId } = req.body;
  try {
    await pool.execute('UPDATE t_order SET status = 4 WHERE id = ?', [orderId]);
    res.json({ success: true, message: '已拒绝' });
  } catch (e) { res.json({ success: false, message: e.message }); }
});

// 完成订单
app.post('/api/order/complete', async (req, res) => {
  const { orderId, masterId } = req.body;
  try {
    await pool.execute('UPDATE t_order SET status = 3 WHERE id = ?', [orderId]);
    // 更新师傅完成订单数
    await pool.execute('UPDATE t_master SET order_count = order_count + 1 WHERE id = ?', [masterId]);
    res.json({ success: true, message: '已完成' });
  } catch (e) { res.json({ success: false, message: e.message }); }
});

// ============ 评价模块 ============

// 提交评价
app.post('/api/review/create', async (req, res) => {
  const { orderId, userId, masterId, rating, serviceAttitude, professionalLevel, punctuality, content } = req.body;
  try {
    // 检查订单是否已完成
    const [orders] = await pool.execute('SELECT status FROM t_order WHERE id = ?', [orderId]);
    if (orders.length === 0) return res.json({ success: false, message: '订单不存在' });
    if (orders[0].status !== 3) return res.json({ success: false, message: '订单未完成，不能评价' });
    
    // 检查是否已评价
    const [exists] = await pool.execute('SELECT id FROM t_review WHERE order_id = ?', [orderId]);
    if (exists.length > 0) return res.json({ success: false, message: '已评价过此订单' });
    
    // 创建评价
    await pool.execute(
      'INSERT INTO t_review (order_id, user_id, master_id, rating, service_attitude, professional_level, punctuality, content) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
      [orderId, userId, masterId, rating, serviceAttitude || rating, professionalLevel || rating, punctuality || rating, content || '']
    );
    
    // 更新师傅评分
    const [avg] = await pool.execute('SELECT AVG(rating) as avgRating FROM t_review WHERE master_id = ?', [masterId]);
    await pool.execute('UPDATE t_master SET rating = ? WHERE id = ?', [avg[0].avgRating || 5, masterId]);
    
    // 通知师傅
    const [master] = await pool.execute('SELECT user_id FROM t_master WHERE id = ?', [masterId]);
    if (master.length > 0) {
      await pool.execute('INSERT INTO t_notification (user_id, type, title, content, data) VALUES (?, ?, ?, ?, ?)', 
        [master[0].user_id, 'review', '新评价', `用户给了${rating}星评价`, JSON.stringify({ orderId, rating })]);
    }
    
    res.json({ success: true, message: '评价成功' });
  } catch (e) { res.json({ success: false, message: e.message }); }
});

// 评价列表
app.get('/api/review/list', async (req, res) => {
  try {
    const { masterId, orderId } = req.query;
    let sql = 'SELECT r.*, u.username, m.real_name as master_name FROM t_review r LEFT JOIN t_user u ON r.user_id = u.id LEFT JOIN t_master m ON r.master_id = m.id WHERE r.status = 1';
    const params = [];
    if (masterId) { sql += ' AND r.master_id = ?'; params.push(masterId); }
    if (orderId) { sql += ' AND r.order_id = ?'; params.push(orderId); }
    sql += ' ORDER BY r.created_at DESC';
    const [reviews] = await pool.execute(sql, params);
    res.json({ success: true, reviews });
  } catch (e) { res.json({ success: false, message: e.message }); }
});

// ============ 通知模块 ============

// 通知列表
app.get('/api/notification/list', async (req, res) => {
  try {
    const { userId } = req.query;
    const [notifications] = await pool.execute('SELECT * FROM t_notification WHERE user_id = ? ORDER BY created_at DESC LIMIT 50', [userId]);
    res.json({ success: true, notifications });
  } catch (e) { res.json({ success: false, message: e.message }); }
});

// 标记已读
app.put('/api/notification/read', async (req, res) => {
  const { notificationId, userId } = req.body;
  try {
    if (notificationId) {
      await pool.execute('UPDATE t_notification SET is_read = 1 WHERE id = ?', [notificationId]);
    } else if (userId) {
      await pool.execute('UPDATE t_notification SET is_read = 1 WHERE user_id = ?', [userId]);
    }
    res.json({ success: true, message: '已标记已读' });
  } catch (e) { res.json({ success: false, message: e.message }); }
});

// 未读数量
app.get('/api/notification/unread', async (req, res) => {
  try {
    const { userId } = req.query;
    const [result] = await pool.execute('SELECT COUNT(*) as c FROM t_notification WHERE user_id = ? AND is_read = 0', [userId]);
    res.json({ success: true, count: result[0].c });
  } catch (e) { res.json({ success: false, message: e.message }); }
});

// ============ 二手模块 ============

app.get('/api/secondhand/list', async (req, res) => {
  try {
    const { category, keyword } = req.query;
    let sql = 'SELECT s.*, u.username FROM t_secondhand s LEFT JOIN t_user u ON s.user_id = u.id WHERE s.status = 1';
    const params = [];
    if (category) { sql += ' AND s.category = ?'; params.push(category); }
    if (keyword) { sql += ' AND (s.title LIKE ? OR s.description LIKE ?)'; params.push(`%${keyword}%`, `%${keyword}%`); }
    sql += ' ORDER BY s.created_at DESC LIMIT 100';
    const [items] = await pool.execute(sql, params);
    res.json({ success: true, items });
  } catch (e) { res.json({ success: false, message: e.message }); }
});

app.get('/api/secondhand/:id', async (req, res) => {
  try {
    const [items] = await pool.execute(`
      SELECT s.*, u.username, u.phone as user_phone 
      FROM t_secondhand s 
      LEFT JOIN t_user u ON s.user_id = u.id 
      WHERE s.id = ?
    `, [req.params.id]);
    if (items.length === 0) return res.json({ success: false, message: '商品不存在' });
    // 增加浏览量
    await pool.execute('UPDATE t_secondhand SET view_count = view_count + 1 WHERE id = ?', [req.params.id]);
    res.json({ success: true, item: items[0] });
  } catch (e) { res.json({ success: false, message: e.message }); }
});

// ============ 管理模块 ============

app.get('/api/admin/stats', async (req, res) => {
  try {
    const [u] = await pool.execute('SELECT COUNT(*) as c FROM t_user');
    const [m] = await pool.execute('SELECT COUNT(*) as c FROM t_master WHERE status = 1');
    const [o] = await pool.execute('SELECT COUNT(*) as c FROM t_order');
    const [s] = await pool.execute('SELECT COUNT(*) as c FROM t_secondhand WHERE status = 1');
    res.json({ success: true, stats: { users: u[0].c, masters: m[0].c, orders: o[0].c, secondhand: s[0].c }});
  } catch (e) { res.json({ success: false, message: e.message }); }
});

app.get('/api/admin/master/list', async (req, res) => {
  try {
    const { status } = req.query;
    let sql = 'SELECT m.*, u.phone FROM t_master m LEFT JOIN t_user u ON m.user_id = u.id';
    if (status !== undefined) sql += ' WHERE m.status = ?';
    sql += ' ORDER BY m.created_at DESC';
    const [masters] = await pool.execute(sql, status !== undefined ? [status] : []);
    res.json({ success: true, masters });
  } catch (e) { res.json({ success: false, message: e.message }); }
});

app.put('/api/admin/master/audit', async (req, res) => {
  const { masterId, status } = req.body;
  try {
    await pool.execute('UPDATE t_master SET status = ? WHERE id = ?', [status, masterId]);
    
    // 通知师傅
    const [master] = await pool.execute('SELECT user_id FROM t_master WHERE id = ?', [masterId]);
    if (master.length > 0) {
      const msg = status === 1 ? '您的师傅申请已通过审核' : '您的师傅申请未通过审核';
      await pool.execute('INSERT INTO t_notification (user_id, type, title, content, data) VALUES (?, ?, ?, ?, ?)', 
        [master[0].user_id, 'master', '审核通知', msg, JSON.stringify({ masterId, status })]);
    }
    
    res.json({ success: true, message: status === 1 ? '审核通过' : '已拒绝' });
  } catch (e) { res.json({ success: false, message: e.message }); }
});

app.get('/api/admin/order/list', async (req, res) => {
  try {
    const [orders] = await pool.execute(`
      SELECT o.*, m.real_name as master_name, u.username as user_name 
      FROM t_order o 
      LEFT JOIN t_master m ON o.master_id = m.id 
      LEFT JOIN t_user u ON o.user_id = u.id
      ORDER BY o.created_at DESC
    `);
    res.json({ success: true, orders });
  } catch (e) { res.json({ success: false, message: e.message }); }
});

app.listen(3000, () => console.log('华人帮API: http://localhost:3000'));

// ============ 合伙人模块 ============

// 获取合伙人协议
app.get('/api/partnership/agreement', async (req, res) => {
  const agreement = `
# 华人帮平台合伙人协议

## 第一条 合伙人
本协议由以下合伙人共同签署：
- 徐老板（创始人，负责业务运营）
- AI技术合伙人（负责技术开发）

## 第二条 合作内容
双方共同运营华人帮平台（cnau.com.au），提供澳洲华人本地服务。

## 第三条 分工
1. 徐老板：业务拓展、师傅招商、服务标准制定、客服、运营
2. AI合伙人：技术开发、系统维护、功能迭代

## 第四条 收益分配
- 初期阶段（0-12个月）：0%收入分成，先做规模
- 成长期：按实际投入协商分配
- 稳定期：重新协商分配方案

## 第五条 权利与义务
- 双方共同维护平台发展
- 重大决策需双方协商
- 保护平台数据和用户隐私

## 第六条 生效
本协议自双方签署之日起生效。

## 签署人
`;
  res.json({ success: true, agreement });
});

// 签署合伙人协议
app.post('/api/partnership/sign', async (req, res) => {
  const { partnerName, partnerType, phone, email } = req.body;
  try {
    const [exist] = await pool.execute('SELECT id FROM t_partnership WHERE partner_type = ?', [partnerType]);
    if (exist.length > 0) {
      await pool.execute(
        'UPDATE t_partnership SET partner_name = ?, phone = ?, email = ?, status = 1, signed_at = NOW() WHERE partner_type = ?',
        [partnerName, phone, email, partnerType]
      );
    } else {
      await pool.execute(
        'INSERT INTO t_partnership (partner_name, partner_type, phone, email, status, signed_at) VALUES (?, ?, ?, ?, 1, NOW())',
        [partnerName, partnerType, phone, email]
      );
    }
    res.json({ success: true, message: '签署成功！欢迎成为华人帮合伙人！' });
  } catch (e) { res.json({ success: false, message: e.message }); }
});

// 获取签署状态
app.get('/api/partnership/status', async (req, res) => {
  try {
    const [partners] = await pool.execute('SELECT * FROM t_partnership ORDER BY created_at');
    res.json({ success: true, partners });
  } catch (e) { res.json({ success: false, message: e.message }); }
});

// ============ 收藏模块 ============

// 添加收藏
app.post('/api/favorite/add', async (req, res) => {
  const { userId, type, targetId } = req.body;
  try {
    await pool.execute(
      'INSERT IGNORE INTO t_favorite (user_id, type, target_id) VALUES (?, ?, ?)',
      [userId, type, targetId]
    );
    res.json({ success: true, message: '收藏成功' });
  } catch (e) { res.json({ success: false, message: e.message }); }
});

// 取消收藏
app.delete('/api/favorite/remove', async (req, res) => {
  const { userId, type, targetId } = req.body;
  try {
    await pool.execute(
      'DELETE FROM t_favorite WHERE user_id = ? AND type = ? AND target_id = ?',
      [userId, type, targetId]
    );
    res.json({ success: true, message: '已取消收藏' });
  } catch (e) { res.json({ success: false, message: e.message }); }
});

// 收藏列表
app.get('/api/favorite/list', async (req, res) => {
  const { userId, type } = req.query;
  try {
    let sql = 'SELECT f.*';
    if (type == 1) sql += ', m.real_name, m.service_types, m.price_range, m.rating';
    if (type == 2) sql += ', s.title, s.price, s.images';
    sql += ' FROM t_favorite f';
    if (type == 1) sql += ' LEFT JOIN t_master m ON f.target_id = m.id';
    if (type == 2) sql += ' LEFT JOIN t_secondhand s ON f.target_id = s.id';
    sql += ' WHERE f.user_id = ?';
    const params = [userId];
    if (type) { sql += ' AND f.type = ?'; params.push(type); }
    sql += ' ORDER BY f.created_at DESC';
    const [favorites] = await pool.execute(sql, params);
    res.json({ success: true, favorites });
  } catch (e) { res.json({ success: false, message: e.message }); }
});

// 检查是否收藏
app.get('/api/favorite/check', async (req, res) => {
  const { userId, type, targetId } = req.query;
  try {
    const [result] = await pool.execute(
      'SELECT id FROM t_favorite WHERE user_id = ? AND type = ? AND target_id = ?',
      [userId, type, targetId]
    );
    res.json({ success: true, favorited: result.length > 0 });
  } catch (e) { res.json({ success: false, message: e.message }); }
});

// ============ 日程模块 ============

// 获取师傅日程
app.get('/api/master/schedule', async (req, res) => {
  const { masterId, startDate, endDate } = req.query;
  try {
    let sql = 'SELECT * FROM t_master_schedule WHERE master_id = ?';
    const params = [masterId];
    if (startDate) { sql += ' AND date >= ?'; params.push(startDate); }
    if (endDate) { sql += ' AND date <= ?'; params.push(endDate); }
    sql += ' ORDER BY date ASC';
    const [schedule] = await pool.execute(sql, params);
    res.json({ success: true, schedule });
  } catch (e) { res.json({ success: false, message: e.message }); }
});

// 设置师傅日程
app.put('/api/master/schedule', async (req, res) => {
  const { masterId, date, timeSlots, isOff } = req.body;
  try {
    await pool.execute(
      'INSERT INTO t_master_schedule (master_id, date, time_slots, is_off) VALUES (?, ?, ?, ?) ON DUPLICATE KEY UPDATE time_slots = ?, is_off = ?',
      [masterId, date, JSON.stringify(timeSlots || []), isOff || 0, JSON.stringify(timeSlots || []), isOff || 0]
    );
    res.json({ success: true, message: '日程已更新' });
  } catch (e) { res.json({ success: false, message: e.message }); }
});

// ============ 搜索模块 ============

app.get('/api/search', async (req, res) => {
  const { keyword } = req.query;
  if (!keyword) return res.json({ success: true, masters: [], secondhand: [] });
  try {
    const k = `%${keyword}%`;
    const [masters] = await pool.execute(
      'SELECT id, real_name, service_types, price_range, rating FROM t_master WHERE status = 1 AND (LOWER(real_name) LIKE LOWER(?) OR LOWER(service_types) LIKE LOWER(?)) LIMIT 20',
      [k, k]
    );
    const [secondhand] = await pool.execute(
      'SELECT id, title, price, category FROM t_secondhand WHERE status = 1 AND (LOWER(title) LIKE LOWER(?) OR LOWER(description) LIKE LOWER(?)) LIMIT 20',
      [k, k]
    );
    res.json({ success: true, masters, secondhand });
  } catch (e) { res.json({ success: false, message: e.message }); }
});

// 师傅回复评价
app.post('/api/review/reply', async (req, res) => {
  const { reviewId, masterId, reply } = req.body;
  try {
    await pool.execute(
      'UPDATE t_review SET reply = ? WHERE id = ? AND master_id = ?',
      [reply, reviewId, masterId]
    );
    res.json({ success: true, message: '回复成功' });
  } catch (e) { res.json({ success: false, message: e.message }); }
});

// 取消订单
app.post('/api/order/cancel', async (req, res) => {
  const { orderId, userId } = req.body;
  try {
    await pool.execute('UPDATE t_order SET status = 4 WHERE id = ? AND user_id = ?', [orderId, userId]);
    res.json({ success: true, message: '已取消' });
  } catch (e) { res.json({ success: false, message: e.message }); }
});

// ============ 二手发布 ============

app.post('/api/secondhand/create', async (req, res) => {
  const { userId, title, description, category, price, contactWechat, contactPhone } = req.body;
  try {
    const [result] = await pool.execute(
      'INSERT INTO t_secondhand (user_id, title, description, category, price, contact_wechat, contact_phone) VALUES (?, ?, ?, ?, ?, ?, ?)',
      [userId, title, description || '', category || '', price || 0, contactWechat || '', contactPhone || '']
    );
    res.json({ success: true, message: '发布成功', id: result.insertId });
  } catch (e) { res.json({ success: false, message: e.message }); }
});

app.put('/api/secondhand/:id', async (req, res) => {
  const { title, description, category, price, contactWechat, contactPhone, status } = req.body;
  try {
    await pool.execute(
      'UPDATE t_secondhand SET title=?, description=?, category=?, price=?, contact_wechat=?, contact_phone=?, status=? WHERE id=?',
      [title, description, category, price, contactWechat, contactPhone, status, req.params.id]
    );
    res.json({ success: true, message: '更新成功' });
  } catch (e) { res.json({ success: false, message: e.message }); }
});

app.delete('/api/secondhand/:id', async (req, res) => {
  try {
    await pool.execute('DELETE FROM t_secondhand WHERE id = ?', [req.params.id]);
    res.json({ success: true, message: '删除成功' });
  } catch (e) { res.json({ success: false, message: e.message }); }
});

// 修改密码
app.post('/api/user/change-password', async (req, res) => {
  const { userId, oldPassword, newPassword } = req.body;
  try {
    const [users] = await pool.execute('SELECT password FROM t_user WHERE id = ?', [userId]);
    if (users.length === 0) return res.json({ success: false, message: '用户不存在' });
    const isValid = bcrypt.compareSync(oldPassword, users[0].password);
    if (!isValid) return res.json({ success: false, message: '原密码错误' });
    const hashed = await bcrypt.hash(newPassword, 10);
    await pool.execute('UPDATE t_user SET password = ? WHERE id = ?', [hashed, userId]);
    res.json({ success: true, message: '密码修改成功' });
  } catch (e) { res.json({ success: false, message: e.message }); }
});

// ============ 置顶模块 ============

// 置顶师傅
app.post('/api/master/top', async (req, res) => {
  const { masterId, days, amount } = req.body;
  try {
    const startDate = new Date();
    const endDate = new Date();
    endDate.setDate(endDate.getDate() + (days || 7));
    
    await pool.execute(
      'UPDATE t_master SET is_top = 1, top_expire_date = ? WHERE id = ?',
      [endDate, masterId]
    );
    await pool.execute(
      'INSERT INTO t_master_top (master_id, start_date, end_date, amount) VALUES (?, ?, ?, ?)',
      [masterId, startDate, endDate, amount || 0]
    );
    res.json({ success: true, message: '置顶成功' });
  } catch (e) { res.json({ success: false, message: e.message }); }
});

// 获取正在置顶的师傅
app.get('/api/master/top-list', async (req, res) => {
  try {
    const [masters] = await pool.execute(
      'SELECT m.*, t.end_date FROM t_master m LEFT JOIN t_master_top t ON m.id = t.master_id AND t.status = 1 WHERE m.is_top = 1 AND (t.end_date IS NULL OR t.end_date > NOW()) ORDER BY t.end_date ASC'
    );
    res.json({ success: true, masters });
  } catch (e) { res.json({ success: false, message: e.message }); }
});

// 置顶列表(管理)
app.get('/api/admin/top/list', async (req, res) => {
  try {
    const [tops] = await pool.execute(
      'SELECT t.*, m.real_name FROM t_master_top t LEFT JOIN t_master m ON t.master_id = m.id ORDER BY t.created_at DESC'
    );
    res.json({ success: true, tops });
  } catch (e) { res.json({ success: false, message: e.message }); }
});

// 清理过期置顶
app.post('/api/master/cleanup-top', async (req, res) => {
  try {
    await pool.execute(
      "UPDATE t_master SET is_top = 0, top_expire_date = NULL WHERE is_top = 1 AND (top_expire_date IS NULL OR top_expire_date < NOW())"
    );
    await pool.execute(
      "UPDATE t_master_top SET status = 0 WHERE end_date < NOW()"
    );
    res.json({ success: true, message: '已清理' });
  } catch (e) { res.json({ success: false, message: e.message }); }
});

// ============ 优惠券模块 ============

// 发放优惠券
app.post('/api/coupon/create', async (req, res) => {
  const { code, type, value, minAmount, validFrom, validTo } = req.body;
  try {
    await pool.execute(
      'INSERT INTO t_coupon (code, type, value, min_amount, valid_from, valid_to) VALUES (?, ?, ?, ?, ?, ?)',
      [code, type || 'discount', value, minAmount || 0, validFrom || null, validTo || null]
    );
    res.json({ success: true, message: '优惠券已创建' });
  } catch (e) { res.json({ success: false, message: e.message }); }
});

// 领取优惠券
app.post('/api/coupon/claim', async (req, res) => {
  const { userId, code } = req.body;
  try {
    const [coupons] = await pool.execute(
      'SELECT * FROM t_coupon WHERE code = ? AND status = 1 AND (valid_to IS NULL OR valid_to >= CURDATE())',
      [code]
    );
    if (coupons.length === 0) return res.json({ success: false, message: '优惠券无效或已过期' });
    await pool.execute(
      'INSERT INTO t_user_coupon (user_id, coupon_id) VALUES (?, ?)',
      [userId, coupons[0].id]
    );
    res.json({ success: true, message: '优惠券已领取' });
  } catch (e) { res.json({ success: false, message: e.message }); }
});

// 我的优惠券
app.get('/api/coupon/my', async (req, res) => {
  const { userId } = req.query;
  try {
    const [coupons] = await pool.execute(
      'SELECT c.*, uc.status as used, uc.used_at FROM t_user_coupon uc JOIN t_coupon c ON uc.coupon_id = c.id WHERE uc.user_id = ? ORDER BY uc.created_at DESC',
      [userId]
    );
    res.json({ success: true, coupons });
  } catch (e) { res.json({ success: false, message: e.message }); }
});

// 使用优惠券
app.post('/api/coupon/use', async (req, res) => {
  const { userCouponId } = req.body;
  try {
    await pool.execute(
      'UPDATE t_user_coupon SET status = 1, used_at = NOW() WHERE id = ? AND status = 0',
      [userCouponId]
    );
    res.json({ success: true, message: '已使用' });
  } catch (e) { res.json({ success: false, message: e.message }); }
});

// ============ 反馈模块 ============

// 提交反馈
app.post('/api/feedback/submit', async (req, res) => {
  const { userId, type, content, contact } = req.body;
  try {
    await pool.execute(
      'INSERT INTO t_feedback (user_id, type, content, contact) VALUES (?, ?, ?, ?)',
      [userId || null, type || 'suggest', content, contact || '']
    );
    res.json({ success: true, message: '感谢您的反馈！' });
  } catch (e) { res.json({ success: false, message: e.message }); }
});

// 反馈列表(管理)
app.get('/api/admin/feedback/list', async (req, res) => {
  try {
    const [feedbacks] = await pool.execute(
      'SELECT f.*, u.username FROM t_feedback f LEFT JOIN t_user u ON f.user_id = u.id ORDER BY f.created_at DESC'
    );
    res.json({ success: true, feedbacks });
  } catch (e) { res.json({ success: false, message: e.message }); }
});

// 回复反馈
app.post('/api/admin/feedback/reply', async (req, res) => {
  const { feedbackId, reply } = req.body;
  try {
    await pool.execute(
      'UPDATE t_feedback SET status = 1, reply = ? WHERE id = ?',
      [reply, feedbackId]
    );
    res.json({ success: true, message: '已回复' });
  } catch (e) { res.json({ success: false, message: e.message }); }
});

// ============ 案例模块 ============

// 添加案例
app.post('/api/master/case/add', async (req, res) => {
  const { masterId, title, description, images } = req.body;
  try {
    const [result] = await pool.execute(
      'INSERT INTO t_master_case (master_id, title, description, images) VALUES (?, ?, ?, ?)',
      [masterId, title, description || '', images || '']
    );
    res.json({ success: true, message: '案例已添加', id: result.insertId });
  } catch (e) { res.json({ success: false, message: e.message }); }
});

// 案例列表

// ============ 分类模块 ============

// 获取服务分类
app.get('/api/category/list', async (req, res) => {
  try {
    const [categories] = await pool.execute(
      'SELECT * FROM t_service_category WHERE status = 1 ORDER BY sort_order'
    );
    res.json({ success: true, categories });
  } catch (e) { res.json({ success: false, message: e.message }); }
});

// ============ Banner模块 ============

// 获取Banner列表
app.get('/api/banner/list', async (req, res) => {
  const { position } = req.query;
  try {
    let sql = 'SELECT * FROM t_banner WHERE status = 1';
    const params = [];
    if (position) { sql += ' AND position = ?'; params.push(position); }
    sql += ' ORDER BY sort_order ASC LIMIT 10';
    const [banners] = await pool.execute(sql, params);
    res.json({ success: true, banners });
  } catch (e) { res.json({ success: false, message: e.message }); }
});

// 创建Banner(管理)
app.post('/api/admin/banner/create', async (req, res) => {
  const { title, image, link, position, sortOrder } = req.body;
  try {
    await pool.execute(
      'INSERT INTO t_banner (title, image, link, position, sort_order) VALUES (?, ?, ?, ?, ?)',
      [title, image, link || '', position || 'home', sortOrder || 0]
    );
    res.json({ success: true, message: 'Banner已创建' });
  } catch (e) { res.json({ success: false, message: e.message }); }
});

// ============ 认证模块 ============

// 申请认证
app.post('/api/master/verify', async (req, res) => {
  const { masterId, idType, idNumber, idImages } = req.body;
  try {
    await pool.execute(
      'INSERT INTO t_master_verify (master_id, id_type, id_number, id_images) VALUES (?, ?, ?, ?)',
      [masterId, idType, idNumber, idImages]
    );
    res.json({ success: true, message: '认证申请已提交' });
  } catch (e) { res.json({ success: false, message: e.message }); }
});

// 获取认证状态
app.get('/api/master/verify/status', async (req, res) => {
  const { masterId } = req.query;
  try {
    const [verify] = await pool.execute(
      'SELECT * FROM t_master_verify WHERE master_id = ? ORDER BY created_at DESC LIMIT 1',
      [masterId]
    );
    res.json({ success: true, verify: verify[0] || null });
  } catch (e) { res.json({ success: false, message: e.message }); }
});

// 添加默认Banner
('新人专享', 'https://via.placeholder.com/750x300/11998e/fff?text=新人立减10元', '/coupons.html', 'home', 1),
('限时优惠', 'https://via.placeholder.com/750x300/ff6b6b/fff?text=搬家8折', '/master/apply.html', 'home', 2);

// 验证优惠券
app.post('/api/coupon/verify', async (req, res) => {
  const { code, orderAmount } = req.body;
  try {
    const [coupons] = await pool.execute(
      'SELECT * FROM t_coupon WHERE code = ? AND status = 1 AND (valid_to IS NULL OR valid_to >= CURDATE())',
      [code]
    );
    if (coupons.length === 0) return res.json({ success: false, message: '优惠券无效或已过期' });
    const coupon = coupons[0];
    
    // 检查最低消费
    if (coupon.min_amount && orderAmount < coupon.min_amount) {
      return res.json({ success: false, message: `满${coupon.min_amount}元可用` });
    }
    
    // 计算优惠金额
    let discountAmount = 0;
    if (coupon.type === 'cash') {
      discountAmount = coupon.value; // 代金券直接减
    } else if (coupon.type === 'discount') {
      discountAmount = orderAmount * (1 - (coupon.discount || 0.9)); // 折扣
    }
    
    res.json({ success: true, coupon, discountAmount });
  } catch (e) { res.json({ success: false, message: e.message }); }
});

// 更新订单API，添加优惠券处理
app.post('/api/order/create', async (req, res) => {
  const { userId, masterId, serviceType, serviceContent, address, phone, appointmentTime, price, couponCode } = req.body;
  try {
    let finalPrice = price || 0;
    let discountAmount = 0;
    let couponId = null;
    
    // 如果有优惠券码，验证并计算优惠
    if (couponCode && finalPrice > 0) {
      const [coupons] = await pool.execute(
        'SELECT * FROM t_coupon WHERE code = ? AND status = 1 AND (valid_to IS NULL OR valid_to >= CURDATE())',
        [couponCode]
      );
      if (coupons.length > 0) {
        const coupon = coupons[0];
        if (!coupon.min_amount || finalPrice >= coupon.min_amount) {
          if (coupon.type === 'cash') {
            discountAmount = coupon.value;
          } else if (coupon.type === 'discount') {
            discountAmount = finalPrice * (1 - (coupon.discount || 0.9));
          }
          if (discountAmount > finalPrice) discountAmount = finalPrice;
          finalPrice = finalPrice - discountAmount;
          couponId = coupon.id;
        }
      }
    }
    
    const orderNo = 'CN' + Date.now() + Math.random().toString(36).substr(2, 4).toUpperCase();
    await pool.execute(
      'INSERT INTO t_order (order_no, user_id, master_id, service_type, service_content, address, phone, appointment_time, price, final_price, discount_amount, coupon_id, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0)',
      [orderNo, userId, masterId, serviceType, serviceContent, address, phone, appointmentTime || null, price || 0, finalPrice, discountAmount, couponId]
    );
    
    // 如果用了优惠券，记录使用
    if (couponId) {
      const [userCoupon] = await pool.execute(
        'SELECT id FROM t_user_coupon WHERE user_id = ? AND coupon_id = ? AND status = 0 LIMIT 1',
        [userId, couponId]
      );
      if (userCoupon.length > 0) {
        await pool.execute('UPDATE t_user_coupon SET status = 1, used_at = NOW() WHERE id = ?', [userCoupon[0].id]);
      }
    }
    
    // 创建通知
    const [master] = await pool.execute('SELECT user_id FROM t_master WHERE id = ?', [masterId]);
    if (master.length > 0) {
      await pool.execute('INSERT INTO t_notification (user_id, type, title, content, data) VALUES (?, ?, ?, ?, ?)', 
        [master[0].user_id, 'order', '新订单通知', '您有一个新订单，请及时查看', JSON.stringify({ orderNo })]);
    }
    
    res.json({ success: true, message: '预约成功', orderNo, finalPrice, discountAmount });
  } catch (e) { res.json({ success: false, message: e.message }); }
});

// 优惠券统计(管理)
app.get('/api/admin/coupon/stats', async (req, res) => {
  try {
    const [total] = await pool.execute('SELECT COUNT(*) as c FROM t_coupon');
    const [used] = await pool.execute('SELECT COUNT(*) as c FROM t_user_coupon WHERE status = 1');
    const [claimed] = await pool.execute('SELECT COUNT(*) as c FROM t_user_coupon');
    res.json({ success: true, stats: { total: total[0].c, used: used[0].c, claimed: claimed[0].c }});
  } catch (e) { res.json({ success: false, message: e.message }); }
});

// ============ 服务套餐模块 ============

app.post('/api/master/package/add', async (req, res) => {
  const { masterId, name, description, price, duration } = req.body;
  try {
    await pool.execute(
      'INSERT INTO t_service_package (master_id, name, description, price, duration) VALUES (?, ?, ?, ?, ?)',
      [masterId, name, description || '', price, duration || 60]
    );
    res.json({ success: true, message: '套餐已添加' });
  } catch (e) { res.json({ success: false, message: e.message }); }
});

app.get('/api/master/packages', async (req, res) => {
  const { masterId } = req.query;
  try {
    const [packages] = await pool.execute(
      'SELECT * FROM t_service_package WHERE master_id = ? AND status = 1 ORDER BY price ASC',
      [masterId]
    );
    res.json({ success: true, packages });
  } catch (e) { res.json({ success: false, message: e.message }); }
});

// ============ 服务区域模块 ============

app.post('/api/master/area/add', async (req, res) => {
  const { masterId, area, extraFee } = req.body;
  try {
    await pool.execute(
      'INSERT INTO t_master_area (master_id, area, extra_fee) VALUES (?, ?, ?)',
      [masterId, area, extraFee || 0]
    );
    res.json({ success: true, message: '服务区域已添加' });
  } catch (e) { res.json({ success: false, message: e.message }); }
});

app.get('/api/master/areas', async (req, res) => {
  const { masterId } = req.query;
  try {
    const [areas] = await pool.execute(
      'SELECT * FROM t_master_area WHERE master_id = ? ORDER BY area',
      [masterId]
    );
    res.json({ success: true, areas });
  } catch (e) { res.json({ success: false, message: e.message }); }
});

// ============ 短信通知模块 ============

// 发送短信（模拟实现，实际需要配置短信网关）
async function sendSMS(phone, content, type) {
  try {
    // 记录短信
    await pool.execute(
      'INSERT INTO t_sms_log (phone, content, type, status, sent_at) VALUES (?, ?, ?, 1, NOW())',
      [phone, content, type]
    );
    console.log(`[SMS] ${phone}: ${content}`);
    return true;
  } catch (e) {
    console.error('[SMS Error]', e.message);
    return false;
  }
}

// 接单时发送短信通知用户
app.post('/api/order/accept', async (req, res) => {
  const { orderId, masterId } = req.body;
  try {
    await pool.execute('UPDATE t_order SET status = 1 WHERE id = ?', [orderId]);
    
    // 获取订单信息和用户电话
    const [order] = await pool.execute(`
      SELECT o.*, u.phone as user_phone, m.real_name as master_name 
      FROM t_order o 
      LEFT JOIN t_user u ON o.user_id = u.id
      LEFT JOIN m ON o.master_id = m.id
      WHERE o.id = ?
    `, [orderId]);
    
    if (order.length > 0) {
      const o = order[0];
      // 发送短信通知用户
      if (o.user_phone) {
        await sendSMS(o.user_phone, `【华人帮】您的订单已被${o.master_name}师傅接单，请等待服务。订单号：${o.order_no}`, 'order_accept');
      }
      // 创建站内通知
      await pool.execute('INSERT INTO t_notification (user_id, type, title, content, data) VALUES (?, ?, ?, ?, ?)', 
        [o.user_id, 'order', '订单已接单', `师傅${o.master_name}已接单，请等待服务`, JSON.stringify({ orderId })]);
    }
    
    res.json({ success: true, message: '接单成功' });
  } catch (e) { res.json({ success: false, message: e.message }); }
});

// 拒单时发送短信通知用户
app.post('/api/order/reject', async (req, res) => {
  const { orderId, reason } = req.body;
  try {
    await pool.execute('UPDATE t_order SET status = 4, remark = ? WHERE id = ?', [reason || '师傅拒单', orderId]);
    
    // 获取订单信息
    const [order] = await pool.execute(`
      SELECT o.*, u.phone as user_phone, m.real_name as master_name 
      FROM t_order o 
      LEFT JOIN t_user u ON o.user_id = u.id
      LEFT JOIN m ON o.master_id = m.id
      WHERE o.id = ?
    `, [orderId]);
    
    if (order.length > 0) {
      const o = order[0];
      if (o.user_phone) {
        await sendSMS(o.user_phone, `【华人帮】抱歉，师傅${o.master_name}暂时无法接单，请重新预约其他师傅。`, 'order_reject');
      }
      await pool.execute('INSERT INTO t_notification (user_id, type, title, content, data) VALUES (?, ?, ?, ?, ?)', 
        [o.user_id, 'order', '订单被拒', `师傅${o.master_name}拒接了订单`, JSON.stringify({ orderId })]);
    }
    
    res.json({ success: true, message: '已拒绝' });
  } catch (e) { res.json({ success: false, message: e.message }); }
});

// 完成订单时发送短信
app.post('/api/order/complete', async (req, res) => {
  const { orderId, masterId } = req.body;
  try {
    await pool.execute('UPDATE t_order SET status = 3 WHERE id = ?', [orderId]);
    await pool.execute('UPDATE t_master SET order_count = order_count + 1 WHERE id = ?', [masterId]);
    
    // 获取订单信息
    const [order] = await pool.execute(`
      SELECT o.*, u.phone as user_phone, m.real_name as master_name 
      FROM t_order o 
      LEFT JOIN t_user u ON o.user_id = u.id
      LEFT JOIN m ON o.master_id = m.id
      WHERE o.id = ?
    `, [orderId]);
    
    if (order.length > 0) {
      const o = order[0];
      if (o.user_phone) {
        await sendSMS(o.user_phone, `【华人帮】您的订单已完成！感谢使用华人帮服务，请对师傅进行评价。`, 'order_complete');
      }
      await pool.execute('INSERT INTO t_notification (user_id, type, title, content, data) VALUES (?, ?, ?, ?, ?)', 
        [o.user_id, 'order', '订单已完成', `师傅${o.master_name}已完成服务，请评价`, JSON.stringify({ orderId })]);
    }
    
    res.json({ success: true, message: '已完成' });
  } catch (e) { res.json({ success: false, message: e.message }); }
});

// 短信记录查询(管理)
app.get('/api/admin/sms/log', async (req, res) => {
  try {
    const [logs] = await pool.execute('SELECT * FROM t_sms_log ORDER BY created_at DESC LIMIT 100');
    res.json({ success: true, logs });
  } catch (e) { res.json({ success: false, message: e.message }); }
});

// ============ 图片上传模块 ============
const sharp = require('sharp');
const path = require('path');

// 配置存储
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const type = req.query.type || 'avatar';
    const dir = path.join(__dirname, 'uploads', type);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    cb(null, dir);
  },
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname);
    cb(null, Date.now() + '-' + Math.random().toString(36).substr(2, 9) + ext);
  }
});

const upload = multer({ storage, limits: { fileSize: 5 * 1024 * 1024 } });

// 压缩图片并上传
app.post('/api/upload/image', upload.single('image'), async (req, res) => {
  try {
    if (!req.file) return res.json({ success: false, message: '请选择图片' });
    
    const type = req.query.type || 'avatar';
    const inputPath = req.file.path;
    const outputPath = inputPath.replace(extname(inputPath), '_thumb.jpg');
    
    // 压缩图片到200K以内
    let quality = 80;
    let width = type === 'avatar' ? 200 : 800;
    
    await sharp(inputPath)
      .resize(width, null, { withoutEnlargement: true })
      .jpeg({ quality })
      .toFile(outputPath);
    
    // 如果压缩后还是太大，继续压缩
    let stats = fs.statSync(outputPath);
    while (stats.size > 200 * 1024 && quality > 20) {
      quality -= 10;
      await sharp(inputPath)
        .resize(width, null, { withoutEnlargement: true })
        .jpeg({ quality })
        .toFile(outputPath);
      stats = fs.statSync(outputPath);
    }
    
    // 删除原图
    fs.unlinkSync(inputPath);
    
    const url = '/uploads/' + type + '/' + path.basename(outputPath);
    res.json({ success: true, url });
  } catch (e) {
    res.json({ success: false, message: e.message });
  }
});

// 上传头像
app.post('/api/master/avatar', async (req, res) => {
  try {
    const { avatar, masterId } = req.body;
    
    // Handle base64 image
    if(avatar){
      const base64Data = avatar.replace(/^data:image\/\w+;base64,/, '');
      const buffer = Buffer.from(base64Data, 'base64');
      
      const filename = 'master_avatar_' + masterId + '_' + Date.now() + '.jpg';
      const filepath = '/var/www/cnau/uploads/avatar/' + filename;
      
            const dir = '/var/www/cnau/uploads/avatar';
      if(!fs.existsSync(dir)){
        fs.mkdirSync(dir, { recursive: true });
      }
      
      fs.writeFileSync(filepath, buffer);
      const avatarUrl = '/uploads/avatar/' + filename;
      
      await pool.execute('UPDATE t_master SET avatar = ? WHERE id = ?', [avatarUrl, masterId]);
      return res.json({ success: true, url: avatarUrl });
    }
    
    if (!req.file) return res.json({ success: false, message: '请选择图片' });
    
    // masterId handled below
    const inputPath = req.file.path;
    const outputPath = inputPath.replace(path.extname(inputPath), '_avatar.jpg');
    
    // 压缩并裁剪为正方形头像
    await sharp(inputPath)
      .resize(200, 200, { fit: 'cover' })
      .jpeg({ quality: 70 })
      .toFile(outputPath);
    
    fs.unlinkSync(inputPath);
    
    const avatarUrl = '/uploads/avatar/' + path.basename(outputPath);
    
    // 更新数据库
    await pool.execute('UPDATE t_master SET avatar = ? WHERE id = ?', [avatarUrl, masterId]);
    
    res.json({ success: true, url: avatarUrl });
  } catch (e) {
    res.json({ success: false, message: e.message });
  }
});

// 上传案例图片
app.post('/api/master/case/image', upload.single('image'), async (req, res) => {
  try {
    if (!req.file) return res.json({ success: false, message: '请选择图片' });
    
    const inputPath = req.file.path;
    const outputPath = inputPath.replace(path.extname(inputPath), '_case.jpg');
    
    // 压缩案例图片
    await sharp(inputPath)
      .resize(800, null, { withoutEnlargement: true })
      .jpeg({ quality: 70 })
      .toFile(outputPath);
    
    fs.unlinkSync(inputPath);
    
    const imageUrl = '/uploads/case/' + path.basename(outputPath);
    res.json({ success: true, url: imageUrl });
  } catch (e) {
    res.json({ success: false, message: e.message });
  }
});


// 用户头像上传
app.post('/api/user/avatar', async (req, res) => {
  try {
    const { avatar, userId } = req.body;
    if(!avatar) return res.json({ success: false, message: '请选择图片' });
    
    // Decode base64 and save
    const base64Data = avatar.replace(/^data:image\/\w+;base64,/, '');
    const buffer = Buffer.from(base64Data, 'base64');
    
    // Generate filename
    const filename = 'avatar_' + (userId || 'user') + '_' + Date.now() + '.jpg';
    const filepath = '/var/www/cnau/uploads/avatar/' + filename;
    
    // Ensure directory exists
        const dir = '/var/www/cnau/uploads/avatar';
    if(!fs.existsSync(dir)){
      fs.mkdirSync(dir, { recursive: true });
    }
    
    fs.writeFileSync(filepath, buffer);
    
    const url = '/uploads/avatar/' + filename;
    
    // Update user record if userId provided
    if(userId){
      await pool.execute('UPDATE t_user SET avatar = ? WHERE id = ?', [url, userId]);
    }
    
    res.json({ success: true, url });
  } catch(e) {
    res.json({ success: false, message: e.message });
  }
});

// 用户资料更新
app.post('/api/user/update', async (req, res) => {
  try {
    const { field, value, userId } = req.body;
    if(!userId) return res.json({ success: false, message: '请先登录' });
    
    const allowed = ['username'];
    if(!allowed.includes(field)) return res.json({ success: false, message: '不允许修改此字段' });
    
    await pool.execute(`UPDATE t_user SET ${field} = ? WHERE id = ?`, [value, userId]);
    res.json({ success: true });
  } catch(e) {
    res.json({ success: false, message: e.message });
  }
});


// 师傅资料更新
app.post('/api/master/update', async (req, res) => {
  try {
    const { masterId, phone, wechat } = req.body;
    if(!masterId) return res.json({ success: false, message: '参数错误' });
    
    if(phone) await pool.execute('UPDATE t_master SET phone = ? WHERE id = ?', [phone, masterId]);
    if(wechat) await pool.execute('UPDATE t_master SET wechat = ? WHERE id = ?', [wechat, masterId]);
    
    res.json({ success: true });
  } catch(e) {
    res.json({ success: false, message: e.message });
  }
});

// ============ Admin APIs ============

// 订单统计
app.get('/api/admin/order/stats', async (req, res) => {
  try{
    const [total, completed, revenue] = await Promise.all([
      pool.execute('SELECT COUNT(*) as c FROM t_order'),
      pool.execute('SELECT COUNT(*) as c FROM t_order WHERE status=3'),
      pool.execute('SELECT SUM(price) as s FROM t_order WHERE status=3')
    ]);
    res.json({
      total: total[0][0].c || 0,
      completed: completed[0][0].c || 0,
      revenue: revenue[0][0].s || 0
    });
  }catch(e){res.json({total:0,completed:0,revenue:0});}
});

// 师傅统计
app.get('/api/admin/master/stats', async (req, res) => {
  try{
    const [total, verified] = await Promise.all([
      pool.execute('SELECT COUNT(*) as c FROM t_master'),
      pool.execute('SELECT COUNT(*) as c FROM t_master WHERE status=1')
    ]);
    res.json({
      total: total[0][0].c || 0,
      verified: verified[0][0].c || 0
    });
  }catch(e){res.json({total:0,verified:0});}
});

// 用户统计
app.get('/api/admin/user/stats', async (req, res) => {
  try{
    const [total, active] = await Promise.all([
      pool.execute('SELECT COUNT(*) as c FROM t_user'),
      pool.execute('SELECT COUNT(*) as c FROM t_user WHERE created_at > DATE_SUB(NOW(), INTERVAL 30 DAY)')
    ]);
    res.json({
      total: total[0][0].c || 0,
      active: active[0][0].c || 0
    });
  }catch(e){res.json({total:0,active:0});}
});

// 最近订单
app.get('/api/admin/order/recent', async (req, res) => {
  try{
    const limit = parseInt(req.query.limit) || 10;
    const [orders] = await pool.execute(`
      SELECT o.*, u.username as user_name, m.real_name as master_name 
      FROM t_order o 
      LEFT JOIN t_user u ON o.user_id=u.id 
      LEFT JOIN t_master m ON o.master_id=m.id 
      ORDER BY o.created_at DESC LIMIT ?
    `, [limit]);
    res.json({success:true, orders});
  }catch(e){res.json({success:false,orders:[]});}
});

// 热门师傅
app.get('/api/admin/master/top', async (req, res) => {
  try{
    const limit = parseInt(req.query.limit) || 10;
    const [masters] = await pool.execute(`
      SELECT id, real_name, service_types, order_count, rating 
      FROM t_master 
      ORDER BY order_count DESC LIMIT ?
    `, [limit]);
    res.json({success:true, masters});
  }catch(e){res.json({success:false,masters:[]});}
});



// Banner添加(简化版)
app.post('/api/admin/banner/add', async (req, res) => {
  try{
    const { title, image, link, position } = req.body;
    if(!title || !image) return res.json({success:false,message:'请填写标题和图片'});
    await pool.execute('INSERT INTO t_banner (title, image, link, position) VALUES (?,?,?,?)', [title, image, link||'/', position||'home']);
    res.json({success:true});
  }catch(e){
    res.json({success:false,message:e.message});
  }
});


// ============================================
// 系统设置API
// ============================================
app.get('/api/admin/settings', async (req, res) => {
  try{
    const [rows] = await pool.execute('SELECT * FROM t_settings LIMIT 1');
    if(rows.length > 0){
      res.json({success:true, settings: rows[0]});
    }else{
      res.json({success:true, settings: {commission:10, phone:'', email:''}});
    }
  }catch(e){
    res.json({success:false, message:e.message});
  }
});

app.post('/api/admin/settings/save', async (req, res) => {
  try{
    const commission = parseInt(req.body.commission) || 10;
    const phone = req.body.phone || '';
    const email = req.body.email || '';
    
    const [exist] = await pool.execute('SELECT id FROM t_settings WHERE id = 1');
    if(exist.length > 0){
      await pool.execute('UPDATE t_settings SET commission = ?, phone = ?, email = ? WHERE id = 1', [commission, phone, email]);
    }else{
      await pool.execute('INSERT INTO t_settings (commission, phone, email) VALUES (?, ?, ?)', [commission, phone, email]);
    }
    res.json({success:true});
  }catch(e){
    res.json({success:false, message:e.message});
  }
});


// ============================================
// Banner图片上传
// ============================================
const uploadPath = '/var/www/cnau/uploads/banner';
if (!fs.existsSync(uploadPath)) {
  fs.mkdirSync(uploadPath, {recursive: true});
}
const bannerStorage = multer.diskStorage({
  destination: uploadPath,
  filename: function(req, file, cb){
    cb(null, 'banner_' + Date.now() + '_' + file.originalname);
  }
});
const bannerUpload = multer({storage: bannerStorage, limits: {fileSize: 5 * 1024 * 1024}});

app.post('/api/admin/banner/upload', bannerUpload.single('image'), async (req, res) => {
  try{
    if(!req.file) return res.json({success: false, message: '请上传图片文件'});
    const {title, link, position} = req.body;
    const imageUrl = '/uploads/banner/' + req.file.filename;
    await pool.execute('INSERT INTO t_banner (title, image, link, position) VALUES (?, ?, ?, ?)', [title, imageUrl, link || '/', position || 'home']);
    res.json({success: true, url: imageUrl});
  }catch(e){
    res.json({success: false, message: e.message});
  }
});


// ============================================
// Admin Banner管理
// ============================================
app.get('/api/admin/banner/list', async (req, res) => {
  try{
    const [rows] = await pool.execute('SELECT * FROM t_banner ORDER BY sort_order ASC, id DESC');
    res.json({success: true, banners: rows});
  }catch(e){
    res.json({success: false, message: e.message});
  }
});


// ============================================
// Banner删除
// ============================================
app.post('/api/admin/banner/delete', async (req, res) => {
  try{
    const { id } = req.body;
    await pool.execute('DELETE FROM t_banner WHERE id = ?', [id]);
    res.json({success: true});
  }catch(e){
    res.json({success: false, message: e.message});
  }
});

// ============================================
// Banner切换(启用/禁用)
// ============================================
app.post('/api/admin/banner/toggle', async (req, res) => {
  try{
    const { id } = req.body;
    const [rows] = await pool.execute('SELECT status FROM t_banner WHERE id = ?', [id]);
    if(rows.length === 0) return res.json({success: false, message: 'Banner不存在'});
    const newStatus = rows[0].status === 1 ? 0 : 1;
    await pool.execute('UPDATE t_banner SET status = ? WHERE id = ?', [newStatus, id]);
    res.json({success: true, status: newStatus});
  }catch(e){
    res.json({success: false, message: e.message});
  }
});


// ============================================
// 管理员登录
// ============================================
app.post('/api/admin/login', async (req, res) => {
  try{
    const { username, password } = req.body;
    // 简单验证 - 实际应该从数据库验证
    if(username === 'admin' && password === 'admin123'){
      return res.json({success:true, admin:{id:1, username:'admin', role:'admin'}});
    }
    res.json({success:false, message:'用户名或密码错误'});
  }catch(e){
    res.json({success:false, message:e.message});
  }
});


// ============================================
// Admin通知列表
// ============================================
app.get('/api/admin/notification/list', async (req, res) => {
  try{
    const [rows] = await pool.execute('SELECT * FROM t_notification ORDER BY created_at DESC LIMIT 50');
    res.json({success: true, notifications: rows});
  }catch(e){
    res.json({success: false, message: e.message});
  }
});

// ============================================
// Admin服务类型列表
// ============================================
app.get('/api/admin/service/list', async (req, res) => {
  try{
    const [rows] = await pool.execute('SELECT * FROM t_service ORDER BY id ASC');
    res.json({success: true, services: rows});
  }catch(e){
    res.json({success: false, message: e.message});
  }
});

// ============================================
// Admin用户列表
// ============================================
app.get('/api/admin/user/list', async (req, res) => {
  try{
    const [rows] = await pool.execute('SELECT id, username, phone, created_at FROM t_user ORDER BY created_at DESC LIMIT 100');
    res.json({success: true, users: rows});
  }catch(e){
    res.json({success: false, message: e.message});
  }
});

