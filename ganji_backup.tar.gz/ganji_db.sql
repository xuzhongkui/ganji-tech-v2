-- MySQL dump 10.13  Distrib 8.0.45, for Linux (x86_64)
--
-- Host: localhost    Database: ganji_tech
-- ------------------------------------------------------
-- Server version	8.0.45-0ubuntu0.22.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `addresses`
--

DROP TABLE IF EXISTS `addresses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `addresses` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint NOT NULL,
  `merchant_id` bigint NOT NULL,
  `name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `province` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `district` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `detail` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_default` tinyint DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `merchant_id` (`merchant_id`),
  CONSTRAINT `addresses_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `addresses_ibfk_2` FOREIGN KEY (`merchant_id`) REFERENCES `merchants` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `addresses`
--

LOCK TABLES `addresses` WRITE;
/*!40000 ALTER TABLE `addresses` DISABLE KEYS */;
INSERT INTO `addresses` VALUES (1,3,1,'John','13900000001','CA','Los Angeles','Downtown','123 Main St',1,'2026-02-15 04:50:19'),(2,5,1,'John Doe','13800138001','California','Los Angeles','Downtown','123 Main St',1,'2026-02-15 06:08:00');
/*!40000 ALTER TABLE `addresses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admins`
--

DROP TABLE IF EXISTS `admins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `admins` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `username` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'admin',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admins`
--

LOCK TABLES `admins` WRITE;
/*!40000 ALTER TABLE `admins` DISABLE KEYS */;
INSERT INTO `admins` VALUES (1,'admin','$2y$10$2eeVP4tr0iGRkmZp7SGPB.CJ6bbAIGi.L3GZwNUX0nYHXQBoK30XG','super_admin','2026-02-15 02:53:49');
/*!40000 ALTER TABLE `admins` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `banners`
--

DROP TABLE IF EXISTS `banners`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `banners` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `merchant_id` bigint NOT NULL,
  `title` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `link` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sort_order` int DEFAULT '0',
  `status` tinyint DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `merchant_id` (`merchant_id`),
  CONSTRAINT `banners_ibfk_1` FOREIGN KEY (`merchant_id`) REFERENCES `merchants` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `banners`
--

LOCK TABLES `banners` WRITE;
/*!40000 ALTER TABLE `banners` DISABLE KEYS */;
INSERT INTO `banners` VALUES (1,1,'Welcome to GanjiTech','https://picsum.photos/800/400','http://app.ganji.au',1,1,'2026-02-15 04:30:32'),(2,1,'Summer Sale','https://picsum.photos/800/401','http://app.ganji.au',2,1,'2026-02-15 04:30:32'),(3,1,'New Products','https://picsum.photos/800/402','http://app.ganji.au',3,1,'2026-02-15 04:30:32');
/*!40000 ALTER TABLE `banners` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `carts`
--

DROP TABLE IF EXISTS `carts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `carts` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint NOT NULL,
  `merchant_id` bigint NOT NULL,
  `product_id` bigint NOT NULL,
  `quantity` int DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `merchant_id` (`merchant_id`),
  KEY `product_id` (`product_id`),
  CONSTRAINT `carts_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `carts_ibfk_2` FOREIGN KEY (`merchant_id`) REFERENCES `merchants` (`id`),
  CONSTRAINT `carts_ibfk_3` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `carts`
--

LOCK TABLES `carts` WRITE;
/*!40000 ALTER TABLE `carts` DISABLE KEYS */;
INSERT INTO `carts` VALUES (1,3,1,1,2,'2026-02-15 04:50:20'),(2,5,1,1,2,'2026-02-15 06:08:00'),(3,19,1,1,2,'2026-02-17 06:34:56');
/*!40000 ALTER TABLE `carts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categories` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `merchant_id` bigint NOT NULL,
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name_en` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_id` bigint DEFAULT '0',
  `sort_order` int DEFAULT '0',
  `status` tinyint DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `merchant_id` (`merchant_id`),
  CONSTRAINT `categories_ibfk_1` FOREIGN KEY (`merchant_id`) REFERENCES `merchants` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` VALUES (1,1,'Electronics','Electronics',0,0,1,'2026-02-15 03:38:45'),(4,1,'Clothing','Clothing',0,0,1,'2026-02-15 10:20:46'),(5,1,'Home & Garden','Home & Garden',0,0,1,'2026-02-15 10:20:46'),(6,1,'Sports','Sports',0,0,1,'2026-02-15 10:20:46'),(7,1,'Books','Books',0,0,1,'2026-02-15 10:20:46');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coupons`
--

DROP TABLE IF EXISTS `coupons`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `coupons` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `merchant_id` bigint NOT NULL,
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name_en` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `code` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'fixed' COMMENT 'fixed=固定金额, percent=百分比',
  `value` decimal(10,2) NOT NULL,
  `min_amount` decimal(10,2) DEFAULT '0.00',
  `max_uses` int DEFAULT '0',
  `used_count` int DEFAULT '0',
  `valid_from` date DEFAULT NULL,
  `valid_until` date DEFAULT NULL,
  `status` tinyint DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`),
  KEY `merchant_id` (`merchant_id`),
  CONSTRAINT `coupons_ibfk_1` FOREIGN KEY (`merchant_id`) REFERENCES `merchants` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coupons`
--

LOCK TABLES `coupons` WRITE;
/*!40000 ALTER TABLE `coupons` DISABLE KEYS */;
/*!40000 ALTER TABLE `coupons` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `favorites`
--

DROP TABLE IF EXISTS `favorites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `favorites` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint NOT NULL,
  `product_id` bigint NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_fav` (`user_id`,`product_id`),
  KEY `product_id` (`product_id`),
  CONSTRAINT `favorites_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `favorites_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `favorites`
--

LOCK TABLES `favorites` WRITE;
/*!40000 ALTER TABLE `favorites` DISABLE KEYS */;
INSERT INTO `favorites` VALUES (1,5,1,'2026-02-15 06:08:00'),(2,19,1,'2026-02-17 06:34:57');
/*!40000 ALTER TABLE `favorites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `merchant_orders`
--

DROP TABLE IF EXISTS `merchant_orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `merchant_orders` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `merchant_id` bigint NOT NULL,
  `package_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `payment_status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'pending',
  `payment_method` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `transaction_id` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `paid_at` timestamp NULL DEFAULT NULL,
  `expire_at` date NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `merchant_id` (`merchant_id`),
  CONSTRAINT `merchant_orders_ibfk_1` FOREIGN KEY (`merchant_id`) REFERENCES `merchants` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `merchant_orders`
--

LOCK TABLES `merchant_orders` WRITE;
/*!40000 ALTER TABLE `merchant_orders` DISABLE KEYS */;
/*!40000 ALTER TABLE `merchant_orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `merchants`
--

DROP TABLE IF EXISTS `merchants`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `merchants` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `username` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `merchant_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `merchant_name_en` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `logo` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `banner` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `description_en` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `phone` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `address_en` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `invite_code` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint DEFAULT '1' COMMENT '1=启用 0=停用',
  `package_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'basic' COMMENT 'basic/pro/enterprise',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `package_expire` datetime DEFAULT NULL,
  `package_price` decimal(10,2) DEFAULT '0.00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `invite_code` (`invite_code`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `merchants`
--

LOCK TABLES `merchants` WRITE;
/*!40000 ALTER TABLE `merchants` DISABLE KEYS */;
INSERT INTO `merchants` VALUES (1,'teststore','$2y$10$DQ4fhqYPmO8fr8G/Er/cAe3BI4MCvcNoXHAShKFH466NcEUVKmG2y','Test Store',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'61CF2A38',1,'enterprise','2026-02-15 03:11:48','2026-02-17 07:03:08','2027-02-17 07:02:52',999.00),(2,'test2','$2y$10$XPv8VMsas6rA11yK9yXpPuhSTjYWlhRwL97xaBEKlwrsu4rkhL0TK','Test Shop 2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'8C7DB7E4',1,'basic','2026-02-15 03:36:39','2026-02-15 03:36:39',NULL,0.00),(3,'newstore','$2y$10$3E0OJrcpus8CokekOsueVOaZyJBhqKsmskfIt4Rs1DXR4Rj.4MiEy','New Test Store',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'B8716911',1,'basic','2026-02-15 06:05:19','2026-02-15 06:05:19',NULL,0.00),(4,'test','$2y$10$rJ7AEJ/SmTir8/r07Rocmummbr8Czp0AWelQ6Y3riHONLLdps03eu','test',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'C26286BB',1,'basic','2026-02-16 13:55:47','2026-02-16 13:55:47',NULL,0.00),(5,'testuser1771250887','$2y$10$vzFWGW5XGrs.OQgAtdJFa.DC1LXmNq1EkBpCebnMktp/bCzJcv7Ai','TestStore',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'E41ADFF2',1,'basic','2026-02-16 14:08:07','2026-02-16 14:08:07',NULL,0.00),(6,'shop001','$2y$10$DKK4Z3W/v0/1djHsBIQ/vumMo716CUtcYF136BqUxh8krxN/kx7j2','TestShop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0BD899D3',1,'basic','2026-02-16 14:31:01','2026-02-16 14:31:01',NULL,0.00),(7,'testshop123','$2y$10$pjk9Bksfz52uZA3siUcU.OYlHyey5j5TjYOrbOwTLarcrO4mK9vKq','TestShop123',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'F0A0671D',1,'basic','2026-02-17 06:23:12','2026-02-17 06:23:12',NULL,0.00),(8,'testshop999','$2y$10$lLT63ULhEfXErDznzpesW.bTZfWrb7CSMbwpgZ3Nxx/LojXdSEHwS','TestShop999',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'E3E76AC3',1,'basic','2026-02-17 06:23:13','2026-02-17 06:23:13',NULL,0.00),(9,'newshop001','$2y$10$5MqksijV1oVpUd7zWVIDG.3qiykqCyeOfswl7WqtgaQw0PoI3pgja','NewShop001',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'69E98362',1,'basic','2026-02-17 06:34:28','2026-02-17 06:49:42',NULL,0.00);
/*!40000 ALTER TABLE `merchants` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `messages`
--

DROP TABLE IF EXISTS `messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `messages` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `merchant_id` bigint NOT NULL,
  `user_id` bigint DEFAULT NULL,
  `merchant_user_id` bigint DEFAULT NULL,
  `message_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'text' COMMENT 'text/image',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `sender_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'user/merchant/admin',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `merchant_id` (`merchant_id`),
  CONSTRAINT `messages_ibfk_1` FOREIGN KEY (`merchant_id`) REFERENCES `merchants` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `messages`
--

LOCK TABLES `messages` WRITE;
/*!40000 ALTER TABLE `messages` DISABLE KEYS */;
INSERT INTO `messages` VALUES (1,1,1,0,'text','Hello, I have a question about a product','user','2026-02-15 06:26:12'),(2,1,0,0,'text','Hi! How can I help you today?','merchant','2026-02-15 06:26:18'),(3,1,1,0,'text','Hello, I want to buy a product','user','2026-02-15 06:30:41'),(4,1,0,0,'text','Hi! Thanks for your interest. How can I help?','merchant','2026-02-15 06:30:41'),(5,1,7,0,'text','Test message from API','user','2026-02-15 13:56:37'),(6,1,1,0,'text','Hello, I need help with my order','user','2026-02-17 06:25:02');
/*!40000 ALTER TABLE `messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_items`
--

DROP TABLE IF EXISTS `order_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `order_items` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `order_id` bigint NOT NULL,
  `product_id` bigint NOT NULL,
  `product_name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `price` decimal(10,2) NOT NULL,
  `quantity` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `order_id` (`order_id`),
  KEY `product_id` (`product_id`),
  CONSTRAINT `order_items_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`),
  CONSTRAINT `order_items_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_items`
--

LOCK TABLES `order_items` WRITE;
/*!40000 ALTER TABLE `order_items` DISABLE KEYS */;
INSERT INTO `order_items` VALUES (1,2,1,'Test Product',99.99,3),(3,4,1,'iPhone 15 Pro',99.99,1);
/*!40000 ALTER TABLE `order_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `orders` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `order_no` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `merchant_id` bigint NOT NULL,
  `user_id` bigint NOT NULL,
  `total_amount` decimal(10,2) NOT NULL,
  `status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'pending' COMMENT 'pending/paid/shipped/completed/cancelled',
  `pickup_date` date DEFAULT NULL,
  `remark` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `address_id` bigint DEFAULT NULL,
  `delivery_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'pickup' COMMENT 'pickup/delivery',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `order_no` (`order_no`),
  KEY `merchant_id` (`merchant_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`merchant_id`) REFERENCES `merchants` (`id`),
  CONSTRAINT `orders_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders`
--

LOCK TABLES `orders` WRITE;
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
INSERT INTO `orders` VALUES (2,'ORD202602151408002509',1,5,299.97,'pending',NULL,NULL,NULL,'pickup','2026-02-15 06:08:00','2026-02-15 06:08:00'),(4,'ORD202602151829172327',1,1,99.99,'paid',NULL,NULL,NULL,'pickup','2026-02-15 10:29:17','2026-02-15 10:29:28'),(5,'ORD202602170623515680',1,1,0.00,'pending',NULL,NULL,NULL,'pickup','2026-02-17 06:23:51','2026-02-17 06:23:51'),(6,'ORD202602170633402668',1,1,0.00,'paid',NULL,NULL,NULL,'pickup','2026-02-17 06:33:40','2026-02-17 06:34:11');
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `products` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `merchant_id` bigint NOT NULL,
  `category_id` bigint DEFAULT NULL,
  `name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name_en` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `description_en` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `price` decimal(10,2) NOT NULL,
  `original_price` decimal(10,2) DEFAULT NULL,
  `stock` int DEFAULT '0',
  `images` json DEFAULT NULL,
  `video` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint DEFAULT '1' COMMENT '1=上架 0=下架',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `merchant_id` (`merchant_id`),
  KEY `category_id` (`category_id`),
  CONSTRAINT `products_ibfk_1` FOREIGN KEY (`merchant_id`) REFERENCES `merchants` (`id`),
  CONSTRAINT `products_ibfk_2` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products`
--

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES (1,1,1,'iPhone 15 Pro','iPhone 15 Pro','Latest Apple flagship with A17 chip',NULL,999.99,1099.99,50,'[]',NULL,1,'2026-02-15 03:38:45','2026-02-15 23:06:05'),(2,1,1,'Samsung Galaxy S24','','',NULL,899.99,NULL,100,'[]',NULL,1,'2026-02-15 03:42:36','2026-02-15 23:06:05'),(4,1,1,'MacBook Air M3','','',NULL,1299.99,0.00,100,'[]',NULL,1,'2026-02-15 06:07:48','2026-02-15 23:06:05'),(5,1,6,'Nike Air Max','','',NULL,149.99,0.00,50,'[]',NULL,1,'2026-02-15 06:07:48','2026-02-15 10:21:33'),(6,1,1,'iPhone 15 Pro Max','iPhone 15 Pro Max','Latest Apple flagship smartphone',NULL,1199.99,1299.99,25,NULL,NULL,1,'2026-02-15 10:22:54','2026-02-15 23:06:05'),(7,1,1,'Sony WH-1000XM5','Sony WH-1000XM5','Premium noise cancelling headphones',NULL,349.99,399.99,40,NULL,NULL,1,'2026-02-15 10:22:54','2026-02-15 23:06:05'),(8,1,6,'Adidas Ultraboost','Adidas Ultraboost','Premium running shoes',NULL,179.99,199.99,60,NULL,NULL,1,'2026-02-15 10:22:54','2026-02-15 10:22:54'),(9,1,7,'The Great Gatsby','The Great Gatsby','Classic novel by F. Scott Fitzgerald',NULL,14.99,19.99,200,NULL,NULL,1,'2026-02-15 10:22:54','2026-02-15 10:22:54'),(10,1,1,'TestProduct','','',NULL,99.99,0.00,100,NULL,NULL,1,'2026-02-17 06:24:55','2026-02-17 06:24:55'),(11,9,1,'TestProductNew','','',NULL,199.99,0.00,50,NULL,NULL,1,'2026-02-17 06:35:06','2026-02-17 06:35:06');
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `promotions`
--

DROP TABLE IF EXISTS `promotions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `promotions` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `merchant_id` bigint NOT NULL,
  `user_id` bigint NOT NULL,
  `invite_code` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `reward_amount` decimal(10,2) DEFAULT '0.00',
  `status` tinyint DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `merchant_id` (`merchant_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `promotions_ibfk_1` FOREIGN KEY (`merchant_id`) REFERENCES `merchants` (`id`),
  CONSTRAINT `promotions_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `promotions`
--

LOCK TABLES `promotions` WRITE;
/*!40000 ALTER TABLE `promotions` DISABLE KEYS */;
/*!40000 ALTER TABLE `promotions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `referrals`
--

DROP TABLE IF EXISTS `referrals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `referrals` (
  `id` int NOT NULL AUTO_INCREMENT,
  `merchant_id` int NOT NULL,
  `user_id` int NOT NULL,
  `reward` decimal(10,2) DEFAULT '0.00',
  `status` varchar(20) DEFAULT 'pending',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `referrals`
--

LOCK TABLES `referrals` WRITE;
/*!40000 ALTER TABLE `referrals` DISABLE KEYS */;
/*!40000 ALTER TABLE `referrals` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reviews`
--

DROP TABLE IF EXISTS `reviews`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `reviews` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `order_id` bigint NOT NULL,
  `product_id` bigint NOT NULL,
  `user_id` bigint NOT NULL,
  `rating` int DEFAULT '5' COMMENT '1-5星',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `images` json DEFAULT NULL,
  `status` tinyint DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `order_id` (`order_id`),
  KEY `product_id` (`product_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `reviews_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`),
  CONSTRAINT `reviews_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`),
  CONSTRAINT `reviews_ibfk_3` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reviews`
--

LOCK TABLES `reviews` WRITE;
/*!40000 ALTER TABLE `reviews` DISABLE KEYS */;
/*!40000 ALTER TABLE `reviews` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `settings`
--

DROP TABLE IF EXISTS `settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `settings` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `setting_key` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `setting_value` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `setting_key` (`setting_key`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `settings`
--

LOCK TABLES `settings` WRITE;
/*!40000 ALTER TABLE `settings` DISABLE KEYS */;
INSERT INTO `settings` VALUES (1,'platform_name','GanjiTech','2026-02-15 02:45:59','2026-02-15 02:45:59'),(2,'platform_name_en','GanjiTech','2026-02-15 02:45:59','2026-02-15 02:45:59'),(3,'tech_fee_basic','299','2026-02-15 02:45:59','2026-02-15 02:45:59'),(4,'tech_fee_pro','599','2026-02-15 02:45:59','2026-02-15 02:45:59'),(5,'tech_fee_enterprise','999','2026-02-15 02:45:59','2026-02-15 02:45:59'),(6,'packages','[{\"id\":\"basic\",\"name\":\"Basic\",\"price\":299,\"features\":[\"u5546u54c1u7ba1u7406\",\"u8ba2u5355u7ba1u7406\",\"u5ba2u670du652fu6301\"]},{\"id\":\"pro\",\"name\":\"Pro\",\"price\":599,\"features\":[\"u5168u90e8u57fau7840u529fu80fd\",\"u6570u636eu5206u6790\",\"u4f18u5148u652fu6301\"]},{\"id\":\"enterprise\",\"name\":\"Enterprise\",\"price\":999,\"features\":[\"u5168u90e8u529fu80fd\",\"u4e13u5c5eu5ba2u670d\",\"u5b9au5236u5f00u53d1\"]}]','2026-02-17 06:54:48','2026-02-17 06:54:48');
/*!40000 ALTER TABLE `settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tickets`
--

DROP TABLE IF EXISTS `tickets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tickets` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `merchant_id` bigint NOT NULL,
  `title` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `priority` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'normal',
  `status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'pending',
  `reply` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `admin_id` bigint DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tickets`
--

LOCK TABLES `tickets` WRITE;
/*!40000 ALTER TABLE `tickets` DISABLE KEYS */;
INSERT INTO `tickets` VALUES (1,1,'Need help with payment','How do I integrate payment?','high','resolved','Thank you for your ticket. We will help you soon.',1,'2026-02-15 09:42:12','2026-02-17 06:41:57'),(2,1,'How to add more products','I need to add 100  products, how do I do bulk upload?','normal','resolved','You can use our bulk import feature in Products > Import',1,'2026-02-15 09:44:53','2026-02-15 09:44:53'),(3,1,'Test ticket','Testing ticket system','normal','pending',NULL,NULL,'2026-02-15 09:45:31','2026-02-15 09:45:31'),(4,1,'Need help with payment','How do I integrate payment?','high','pending',NULL,NULL,'2026-02-17 06:25:09','2026-02-17 06:25:09');
/*!40000 ALTER TABLE `tickets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_coupons`
--

DROP TABLE IF EXISTS `user_coupons`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_coupons` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint NOT NULL,
  `coupon_id` bigint NOT NULL,
  `order_id` bigint DEFAULT NULL,
  `used_at` timestamp NULL DEFAULT NULL,
  `status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'unused' COMMENT 'unused/used/expired',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `coupon_id` (`coupon_id`),
  CONSTRAINT `user_coupons_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `user_coupons_ibfk_2` FOREIGN KEY (`coupon_id`) REFERENCES `coupons` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_coupons`
--

LOCK TABLES `user_coupons` WRITE;
/*!40000 ALTER TABLE `user_coupons` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_coupons` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `username` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `merchant_id` bigint NOT NULL,
  `nickname` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `avatar` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `phone` (`phone`),
  KEY `merchant_id` (`merchant_id`),
  CONSTRAINT `users_ibfk_1` FOREIGN KEY (`merchant_id`) REFERENCES `merchants` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,NULL,'13800138001','$2y$10$XpkN.fnLurD6chc9iQP9KuzrJFl8VkJ9ADlsibMBrAa13AetUTkhK',1,'13800138001',NULL,1,'2026-02-15 03:42:29','2026-02-15 03:42:29'),(2,NULL,'13800138002','$2y$10$0HiRxKy3q2SVR2v.vFSln.9Fpd16bheV7hg/NIcsN8zuIWkPgc9n6',1,'13800138002',NULL,1,'2026-02-15 04:24:56','2026-02-15 04:24:56'),(3,NULL,'13900000001','$2y$10$a5aH0RixSt1KPbjlN3wU2.tA35X6NO/wG5CuRe8Lv5Y49Jb.2iEyG',1,'13900000001',NULL,1,'2026-02-15 04:30:55','2026-02-15 04:30:55'),(5,NULL,'13999999999','$2y$10$6/nuLLNqL0UtCnh28rbc0uvoSqWj4wJlrbEb8n3NDMt7eYK6KbQh.',1,'13999999999',NULL,1,'2026-02-15 06:07:48','2026-02-15 06:07:48'),(6,NULL,'13800138000','$2y$10$Lwb.R1tF2s5/zbegKb4WsuRugJ7K7bM4Fk5MkPI87MsdPpryuM.o2',1,'13800138000',NULL,1,'2026-02-15 13:50:18','2026-02-15 13:50:18'),(7,NULL,'18900000001','$2y$10$j.UMg8P4OEalztCyiXH5tOsY9wxfsw1x4rFo93QYp4IYT/l/e9v.m',1,'18900000001',NULL,1,'2026-02-15 13:52:13','2026-02-15 13:52:13'),(8,NULL,'0412345678','$2y$10$w7ucWfydkbpDGPjvXhcVweaLZYaLvZqstLETRU1bEhFiXMw9RxwhK',1,'0412345678',NULL,1,'2026-02-16 14:08:16','2026-02-16 14:08:16'),(9,NULL,'0499999999','$2y$10$wQzEvNFSwJw2TfrcJHrOpeo6HNrOJpF01LJBEtqURjSv8jMIfI5Qy',2,'0499999999',NULL,1,'2026-02-16 14:14:35','2026-02-16 14:31:26'),(10,NULL,'0499999998','$2y$10$81/DyBn01GBSgCb8ONtwO.Vjm8TCKRGLNoKBvVHJxP9OXdCgXKYga',1,'0499999998',NULL,1,'2026-02-16 14:14:35','2026-02-16 14:14:35'),(11,NULL,'0411111111','$2y$10$fpp5oHJwyqkfnk7X/W4Mku0z2602XT4MIdcwT4Kg7vs/1x4XIVz6e',1,'0411111111',NULL,1,'2026-02-16 14:17:50','2026-02-16 14:17:50'),(12,NULL,'0422222222','$2y$10$YI7cFXHX67dr/sNtjmkAaeLyxmuQFVLgfHX3asE8R1ILjYuSrN7fC',1,'0422222222',NULL,1,'2026-02-16 14:17:51','2026-02-16 14:17:51'),(13,NULL,'0433333333','$2y$10$zzQofRPfxbsxv1MgNOzENOZ/r40acVdbxsXwz02zoEFtRPcuecXDK',1,'0433333333',NULL,1,'2026-02-16 14:21:02','2026-02-16 14:21:02'),(14,NULL,'11111111111','$2y$10$ZmWG/bPPYZo9yLzzB9cSkugJaJiQTdmyyTMD5OOAN23/Zaz/LyX9a',1,'11111111111',NULL,1,'2026-02-16 14:25:58','2026-02-16 14:25:58'),(15,NULL,'22222222222','$2y$10$kr3BbGuewrdug20pja.TkuJjRyHB8oT.xGvlC82RRVM1opkejoEs.',1,'22222222222',NULL,1,'2026-02-16 14:25:59','2026-02-16 14:25:59'),(16,NULL,'33333333333','$2y$10$gRhNY6dErE4l3OQFnzjt8eOfzrBnv51QB5bKjtpOF0AV7HQv0V.JO',1,'33333333333',NULL,1,'2026-02-16 14:25:59','2026-02-16 14:25:59'),(17,NULL,'10000000002','$2y$10$H3L5zG1eH5ujkTTHu0SGj.6VchYOJWwWB3euT1R.bdOwOJqkfoBhm',2,'10000000002',NULL,1,'2026-02-16 14:27:14','2026-02-16 14:27:18'),(18,NULL,'13912345678','$2y$10$5cMnpQwteqL32ZGtIXA1P.6ERMSw.dmc3JbC8CCTT0MN9pa4UjXKe',1,'13912345678',NULL,1,'2026-02-17 06:23:38','2026-02-17 06:23:38'),(19,NULL,'13999999002','$2y$10$7BYEN1Y48p4.TCV7uHvZCuUcaaMqIdFRlfcexYf65WpIYzjNpkAJ2',1,'13999999002',NULL,1,'2026-02-17 06:34:44','2026-02-17 06:34:44'),(20,NULL,'13900001111','$2y$10$ymD.Ib.3YevlsLNmEetA3.IHGnoMDOkA9cCxI77Z1U2OqjNeQS5PO',9,NULL,NULL,1,'2026-02-17 06:49:34','2026-02-17 06:49:42'),(21,NULL,'13900003333','$2y$10$UTukgMNYD0vYfFAtkIl9E.dvnU6sACXMMuuN4BTzJmtImfIxELdjO',1,NULL,NULL,1,'2026-02-17 06:51:05','2026-02-17 06:51:05');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-02-17  7:33:22
