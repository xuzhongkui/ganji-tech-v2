<?php
/**
 * Stripe Connect API Endpoints
 * 
 * API Routes:
 * POST /api/stripe/create-account - 创建商户账户
 * GET  /api/stripe/account-status - 获取账户状态
 * GET  /api/stripe/onboarding - 重新生成 onboarding 链接
 * POST /api/stripe/create-payment - 创建支付
 * POST /api/stripe/create-checkout - 创建 Checkout Session
 * POST /api/stripe/webhook - Webhook 回调
 */

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

require_once __DIR__ . '/../config/stripe/stripe_connect.php';

// 简单认证 (生产环境应该更严格)
function verifyApiKey($headers) {
    $apiKey = $headers['Authorization'] ?? $headers['authorization'] ?? '';
    $expectedKey = 'Bearer ' . getenv('API_KEY') ?: 'ganji_secure_key_2024';
    return $apiKey === $expectedKey;
}

$method = $_SERVER['REQUEST_METHOD'];
$path = $_GET['path'] ?? '';
$headers = getallheaders();

// 路由处理
switch ($path) {
    // ========== 商户账户管理 ==========
    
    case 'create-account':
        // POST /api/stripe/create-account
        // Body: { "email": "xxx", "business_name": "xxx" }
        
        if (!verifyApiKey($headers)) {
            http_response_code(401);
            echo json_encode(['error' => 'Unauthorized']);
            exit;
        }
        
        $input = json_decode(file_get_contents('php://input'), true);
        
        if (empty($input['email']) || empty($input['business_name'])) {
            http_response_code(400);
            echo json_encode(['error' => 'Missing required fields: email, business_name']);
            exit;
        }
        
        $stripe = new StripeConnect();
        $result = $stripe->createMerchantAccount($input['email'], $input['business_name']);
        
        if ($result['success']) {
            // 保存 account_id 到数据库
            // TODO: 存入数据库
            echo json_encode($result);
        } else {
            http_response_code(400);
            echo json_encode($result);
        }
        break;
        
    case 'account-status':
        // GET /api/stripe/account-status?account_id=acct_xxx
        
        if (!verifyApiKey($headers)) {
            http_response_code(401);
            echo json_encode(['error' => 'Unauthorized']);
            exit;
        }
        
        $accountId = $_GET['account_id'] ?? '';
        
        if (empty($accountId)) {
            http_response_code(400);
            echo json_encode(['error' => 'Missing account_id']);
            exit;
        }
        
        $stripe = new StripeConnect();
        $result = $stripe->getAccountStatus($accountId);
        echo json_encode($result);
        break;
        
    case 'refresh-onboarding':
        // POST /api/stripe/refresh-onboarding
        // Body: { "account_id": "acct_xxx" }
        
        if (!verifyApiKey($headers)) {
            http_response_code(401);
            echo json_encode(['error' => 'Unauthorized']);
            exit;
        }
        
        $input = json_decode(file_get_contents('php://input'), true);
        $accountId = $input['account_id'] ?? '';
        
        if (empty($accountId)) {
            http_response_code(400);
            echo json_encode(['error' => 'Missing account_id']);
            exit;
        }
        
        $stripe = new StripeConnect();
        $result = $stripe->refreshOnboarding($accountId);
        echo json_encode($result);
        break;
        
    // ========== 支付处理 ==========
    
    case 'create-payment':
        // POST /api/stripe/create-payment
        // Body: { "amount": 1000, "merchant_account_id": "acct_xxx", "order_id": "xxx", "description": "xxx" }
        
        if (!verifyApiKey($headers)) {
            http_response_code(401);
            echo json_encode(['error' => 'Unauthorized']);
            exit;
        }
        
        $input = json_decode(file_get_contents('php://input'), true);
        
        $required = ['amount', 'merchant_account_id', 'order_id'];
        foreach ($required as $field) {
            if (empty($input[$field])) {
                http_response_code(400);
                echo json_encode(['error' => "Missing required field: $field"]);
                exit;
            }
        }
        
        $stripe = new StripeConnect();
        $result = $stripe->createPayment(
            (int) $input['amount'],  // 金额(分)
            $input['merchant_account_id'],
            $input['description'] ?? 'Order #' . $input['order_id'],
            [
                'order_id' => $input['order_id'],
                'merchant_id' => $input['merchant_id'] ?? '',
            ]
        );
        
        if ($result['success']) {
            echo json_encode($result);
        } else {
            http_response_code(400);
            echo json_encode($result);
        }
        break;
        
    case 'create-checkout':
        // POST /api/stripe/create-checkout
        // Body: { "amount": 1000, "merchant_account_id": "acct_xxx", "order_id": "xxx", "customer_email": "xxx" }
        
        if (!verifyApiKey($headers)) {
            http_response_code(401);
            echo json_encode(['error' => 'Unauthorized']);
            exit;
        }
        
        $input = json_decode(file_get_contents('php://input'), true);
        
        $required = ['amount', 'merchant_account_id', 'order_id'];
        foreach ($required as $field) {
            if (empty($input[$field])) {
                http_response_code(400);
                echo json_encode(['error' => "Missing required field: $field"]);
                exit;
            }
        }
        
        $stripe = new StripeConnect();
        $result = $stripe->createCheckoutSession(
            (int) $input['amount'],
            $input['merchant_account_id'],
            $input['order_id'],
            $input['customer_email'] ?? null
        );
        
        if ($result['success']) {
            echo json_encode($result);
        } else {
            http_response_code(400);
            echo json_encode($result);
        }
        break;
        
    case 'payment-status':
        // GET /api/stripe/payment-status?payment_intent_id=pi_xxx
        
        if (!verifyApiKey($headers)) {
            http_response_code(401);
            echo json_encode(['error' => 'Unauthorized']);
            exit;
        }
        
        $paymentIntentId = $_GET['payment_intent_id'] ?? '';
        
        if (empty($paymentIntentId)) {
            http_response_code(400);
            echo json_encode(['error' => 'Missing payment_intent_id']);
            exit;
        }
        
        $stripe = new StripeConnect();
        $result = $stripe->getPaymentStatus($paymentIntentId);
        echo json_encode($result);
        break;
        
    // ========== Webhook ==========
    
    case 'webhook':
        // POST /api/stripe/webhook
        // Stripe 会发送事件通知
        
        $payload = file_get_contents('php://input');
        $sigHeader = $_SERVER['HTTP_STRIPE_SIGNATURE'] ?? '';
        
        $stripe = new StripeConnect();
        $result = $stripe->handleWebhook($payload, $sigHeader);
        
        // 无论成功失败，都返回 200 给 Stripe
        http_response_code(200);
        echo json_encode(['received' => true]);
        break;
        
    // ========== 商户余额/Payout ==========
    
    case 'account-balance':
        // GET /api/stripe/account-balance?account_id=acct_xxx
        
        if (!verifyApiKey($headers)) {
            http_response_code(401);
            echo json_encode(['error' => 'Unauthorized']);
            exit;
        }
        
        $accountId = $_GET['account_id'] ?? '';
        
        if (empty($accountId)) {
            http_response_code(400);
            echo json_encode(['error' => 'Missing account_id']);
            exit;
        }
        
        $stripe = new StripeConnect();
        $result = $stripe->getAccountBalance($accountId);
        echo json_encode($result);
        break;
        
    case 'create-payout':
        // POST /api/stripe/create-payout
        // Body: { "account_id": "acct_xxx", "amount": 5000 }
        
        if (!verifyApiKey($headers)) {
            http_response_code(401);
            echo json_encode(['error' => 'Unauthorized']);
            exit;
        }
        
        $input = json_decode(file_get_contents('php://input'), true);
        
        if (empty($input['account_id']) || empty($input['amount'])) {
            http_response_code(400);
            echo json_encode(['error' => 'Missing required fields: account_id, amount']);
            exit;
        }
        
        $stripe = new StripeConnect();
        $result = $stripe->createPayout($input['account_id'], $input['amount']);
        echo json_encode($result);
        break;
        
    default:
        http_response_code(404);
        echo json_encode(['error' => 'Endpoint not found']);
        break;
}
