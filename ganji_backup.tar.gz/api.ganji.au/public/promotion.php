<?php
header("Content-Type: application/json");
require_once __DIR__."/../config/database.php";
$db = new mysqli(DB_HOST,DB_USER,DB_PASS,DB_NAME);
$db->set_charset("utf8mb4");

$action = $_GET["action"] ?? "";

// Get token
$tok = $_SERVER["HTTP_AUTHORIZATION"] ?? "";
$mid = 0;
if($tok){
    $t = json_decode(base64_decode(str_replace("Bearer ","",$tok)),true);
    $mid = intval($t["merchant_id"] ?? 0);
}

switch($action){
    // Get merchant promotion info
    case "info":
        if(!$mid){
            echo json_encode(["code"=>401]);break;
        }
        $m = $db->query("SELECT id,merchant_name,invite_code FROM merchants WHERE id=".$mid)->fetch_assoc();
        
        // Generate promotion URL
        $promo_url = "https://app.ganji.au/register?code=" . $m["invite_code"];
        
        // Generate QR code URL (using generic QR API)
        $qr_url = "https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=" . urlencode($promo_url);
        
        echo json_encode(["code"=>0,"data"=>[
            "merchant_id"=>$m["id"],
            "merchant_name"=>$m["merchant_name"],
            "invite_code"=>$m["invite_code"],
            "promo_url"=>$promo_url,
            "qr_code"=>$qr_url
        ]]);
        break;
    
    // Track referral (when user registers with code)
    case "track":
        $code = $_GET["code"] ?? "";
        $user_id = $_GET["user_id"] ?? 0;
        
        if(!$code || !$user_id){
            echo json_encode(["code"=>400]);break;
        }
        
        // Get merchant by code
        $merchant = $db->query("SELECT id FROM merchants WHERE invite_code='".$code."'")->fetch_assoc();
        
        if($merchant){
            // Record the referral
            $db->query("INSERT INTO referrals (merchant_id, user_id, created_at) VALUES (".$merchant["id"].",".$user_id.",NOW())");
            echo json_encode(["code"=>0,"msg"=>"Referral tracked"]);
        }else{
            echo json_encode(["code"=>404,"msg"=>"Invalid code"]);
        }
        break;
    
    // Get referral stats
    case "stats":
        if(!$mid){
            echo json_encode(["code"=>401]);break;
        }
        
        $total = $db->query("SELECT COUNT(*) as c FROM referrals WHERE merchant_id=".$mid)->fetch_assoc();
        $this_month = $db->query("SELECT COUNT(*) as c FROM referrals WHERE merchant_id=".$mid." AND MONTH(created_at)=MONTH(NOW())")->fetch_assoc();
        
        echo json_encode(["code"=>0,"data"=>[
            "total_referrals"=>intval($total["c"]),
            "this_month"=>intval($this_month["c"])
        ]]);
        break;
        
    default:
        echo json_encode(["code"=>404]);
}
