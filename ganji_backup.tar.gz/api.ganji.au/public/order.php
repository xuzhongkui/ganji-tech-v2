<?php
header("Content-Type: application/json");
require_once __DIR__."/../config/database.php";
$db = new mysqli(DB_HOST,DB_USER,DB_PASS,DB_NAME);
$action = $_GET["action"] ?? "";
$tok = $_SERVER["HTTP_AUTHORIZATION"] ?? "";
$mid = 0;
if($tok){
    $t = json_decode(base64_decode(str_replace("Bearer ","",$tok)),true);
    $mid = intval($t["merchant_id"] ?? 0);
}
if($action == "types"){
    echo json_encode(["code"=>0,"data"=>[["id"=>"alipay","name"=>"Alipay"],["id"=>"wxpay","name"=>"WeChat Pay"],["id"=>"bank","name"=>"Bank Transfer"]]]);
}else if($action == "package/info"){
    if(!$mid){echo json_encode(["code"=>401]);exit;}
    $r = $db->query("SELECT package_type FROM merchants WHERE id=$mid");
    $m = $r->fetch_assoc();
    echo json_encode(["code"=>0,"data"=>["current_package"=>$m["package_type"]?: "basic","packages"=>[["id"=>"basic","name"=>"Basic","price"=>299],["id"=>"pro","name"=>"Pro","price"=>599],["id"=>"enterprise","name"=>"Enterprise","price"=>999]]]]);
}else if($action == "package/buy"){
    if(!$mid){echo json_encode(["code"=>401]);exit;}
    $pkg = $_POST["package_type"] ?? "basic";
    $prices = ["basic"=>299,"pro"=>599,"enterprise"=>999];
    $price = $prices[$pkg] ?? 299;
    $expire = date("Y-m-d H:i:s", strtotime("+1 year"));
    $db->query("UPDATE merchants SET package_type=\x27".$pkg."\x27,package_expire=\x27".$expire."\x27,package_price=".$price." WHERE id=".$mid);
    echo json_encode(["code"=>0,"data"=>["package"=>$pkg,"price"=>$price,"expire_date"=>$expire]]);
}else{echo json_encode(["code"=>404]);}
