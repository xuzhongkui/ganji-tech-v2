<?php
header("Content-Type: application/json");
require_once __DIR__."/../config/database.php";
$db = new mysqli(DB_HOST,DB_USER,DB_PASS,DB_NAME);
$db->set_charset("utf8mb4");

$action = $_GET["action"] ?? "";

// Get token and merchant_id
$tok = $_SERVER["HTTP_AUTHORIZATION"] ?? "";
$mid = 0;
$uid = 0;
if($tok){
    $t = json_decode(base64_decode(str_replace("Bearer ","",$tok)),true);
    $mid = intval($t["merchant_id"] ?? 0);
    $uid = intval($t["user_id"] ?? 0);
}

switch($action){
    // User bind to merchant via invite code
    case "bind":
        $code = $_POST["invite_code"] ?? "";
        $phone = $_POST["phone"] ?? "";
        $password = $_POST["password"] ?? "";
        
        if(!$code || !$phone || !$password){
            echo json_encode(["code"=>400,"msg"=>"Missing parameters"]);break;
        }
        
        // Find merchant by invite code
        $merchant = $db->query("SELECT id,merchant_name FROM merchants WHERE invite_code='".$code."'")->fetch_assoc();
        if(!$merchant){
            echo json_encode(["code"=>404,"msg"=>"Invalid invite code"]);break;
        }
        
        $merchant_id = $merchant["id"];
        $pwd = password_hash($password,PASSWORD_DEFAULT);
        
        // Check if user exists
        $existing = $db->query("SELECT id FROM users WHERE phone='".$phone."'")->fetch_assoc();
        
        if($existing){
            // Update merchant_id
            $db->query("UPDATE users SET merchant_id=".$merchant_id." WHERE id=".$existing["id"]);
            $user_id = $existing["id"];
        }else{
            // Create new user
            $db->query("INSERT INTO users (phone,password,merchant_id,status) VALUES ('".$phone."','".$pwd."',".$merchant_id.",1)");
            $user_id = $db->insert_id;
        }
        
        $token = base64_encode(json_encode(["user_id"=>$user_id,"merchant_id"=>$merchant_id,"time"=>time()]));
        echo json_encode(["code"=>0,"data"=>[
            "token"=>$token,
            "merchant_id"=>$merchant_id,
            "merchant_name"=>$merchant["merchant_name"]
        ]]);
        break;
    
    // User switch merchant
    case "switch":
        if(!$uid){
            echo json_encode(["code"=>401]);break;
        }
        
        $new_code = $_POST["invite_code"] ?? "";
        if(!$new_code){
            echo json_encode(["code"=>400,"msg"=>"Missing invite_code"]);break;
        }
        
        $merchant = $db->query("SELECT id,merchant_name FROM merchants WHERE invite_code='".$new_code."'")->fetch_assoc();
        if(!$merchant){
            echo json_encode(["code"=>404,"msg"=>"Invalid invite code"]);break;
        }
        
        $db->query("UPDATE users SET merchant_id=".$merchant["id"]." WHERE id=".$uid);
        
        $token = base64_encode(json_encode(["user_id"=>$uid,"merchant_id"=>$merchant["id"],"time"=>time()]));
        echo json_encode(["code"=>0,"data"=>[
            "token"=>$token,
            "merchant_id"=>$merchant["id"],
            "merchant_name"=>$merchant["merchant_name"]
        ]]);
        break;
    
    // Get current merchant info
    case "merchant":
        if(!$mid){
            echo json_encode(["code"=>401]);break;
        }
        $m = $db->query("SELECT id,merchant_name,logo,banner,invite_code FROM merchants WHERE id=".$mid)->fetch_assoc();
        echo json_encode(["code"=>0,"data"=>$m]);
        break;
        
    default:
        echo json_encode(["code"=>404,"msg"=>"Action not found"]);
}
