<?php
header("Content-Type: application/json");

// Use msmtp for sending emails
$to = $_POST["to"] ?? "zk@admei.net";
$subject = $_POST["subject"] ?? "GanjiTech Notification";
$message = $_POST["message"] ?? "";
$type = $_POST["type"] ?? "notification";

// Build email content
$html = "<html><body>";
$html .= "<h2>GanjiTech - " . $subject . "</h2>";
$html .= "<p>" . nl2br($message) . "</p>";
$html .= "<hr><p style='color:#666;font-size:12px;'>";
$html .= "This is an automated notification from GanjiTech Platform.<br>";
$html .= "Time: " . date("Y-m-d H:i:s");
$html .= "</p></body></html>";

// Save to log file instead of sending (for demo)
$log = "/var/log/ganji_notify.log";
$log_msg = "[" . date("Y-m-d H:i:s") . "] [$type] To: $to, Subject: $subject\n";
file_put_contents($log, $log_msg, FILE_APPEND);

echo json_encode(["code"=>0,"msg"=>"Notification queued","type"=>$type]);
