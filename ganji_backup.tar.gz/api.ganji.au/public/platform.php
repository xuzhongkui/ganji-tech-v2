<?php
header("Content-Type: application/json");
require_once __DIR__."/../config/database.php";
$db = new mysqli(DB_HOST,DB_USER,DB_PASS,DB_NAME);
$db->set_charset("utf8mb4");

$action = $_GET["action"] ?? "";

// Admin authentication
$tok = $_SERVER["HTTP_AUTHORIZATION"] ?? "";
$admin_id = 0;
if($tok){
    $t = json_decode(base64_decode(str_replace("Bearer ","",$tok)),true);
    $admin_id = intval($t["admin_id"] ?? 0);
}

if(!$admin_id){
    echo json_encode(["code"=>401,"msg"=>"Unauthorized"]);
    exit;
}

switch($action){
    // List all merchants
    case "merchants":
        $status = $_GET["status"] ?? "";
        $sql = "SELECT * FROM merchants ORDER BY id DESC";
        if($status){
            $sql = "SELECT * FROM merchants WHERE status='".$status."' ORDER BY id DESC";
        }
        $r = $db->query($sql);
        $list = [];
        while($x = $r->fetch_assoc()) $list[] = $x;
        echo json_encode(["code"=>0,"data"=>$list]);
        break;
    
    // Get merchant details
    case "merchant":
        $id = intval($_GET["id"] ?? 0);
        $m = $db->query("SELECT * FROM merchants WHERE id=".$id)->fetch_assoc();
        if(!$m){
            echo json_encode(["code"=>404]);break;
        }
        
        // Get stats
        $orders = $db->query("SELECT COUNT(*) as c FROM orders WHERE merchant_id=".$id)->fetch_assoc();
        $products = $db->query("SELECT COUNT(*) as c FROM products WHERE merchant_id=".$id)->fetch_assoc();
        $users = $db->query("SELECT COUNT(*) as c FROM users WHERE merchant_id=".$id)->fetch_assoc();
        
        $m["stats"] = [
            "orders"=>intval($orders["c"]),
            "products"=>intval($products["c"]),
            "users"=>intval($users["c"])
        ];
        
        echo json_encode(["code"=>0,"data"=>$m]);
        break;
    
    // Update merchant status (enable/disable)
    case "merchant/status":
        $id = intval($_POST["id"] ?? 0);
        $status = $_POST["status"] ?? "";
        
        if(!$id || !$status){
            echo json_encode(["code"=>400]);break;
        }
        
        $db->query("UPDATE merchants SET status='".$status."' WHERE id=".$id);
        echo json_encode(["code"=>0]);
        break;
    
    // Package management
    case "packages":
        // Get or create package settings
        $pkg = $db->query("SELECT * FROM settings WHERE setting_key='packages'")->fetch_assoc();
        if(!$pkg){
            $default = json_encode([
                ["id"=>"basic","name"=>"Basic","price"=>299,"features"=>["商品管理","订单管理","客服支持"]],
                ["id"=>"pro","name"=>"Pro","price"=>599,"features"=>["全部基础功能","数据分析","优先支持"]],
                ["id"=>"enterprise","name"=>"Enterprise","price"=>999,"features"=>["全部功能","专属客服","定制开发"]]
            ]);
            $db->query("INSERT INTO settings (setting_key, setting_value) VALUES ('packages','".$default."')");
            $pkg = ["setting_value"=>$default];
        }
        echo json_encode(["code"=>0,"data"=>json_decode($pkg["setting_value"],true)]);
        break;
    
    // Update packages
    case "packages/update":
        $packages = $_POST["packages"] ?? "";
        if(!$packages){
            echo json_encode(["code"=>400]);break;
        }
        $db->query("UPDATE settings SET setting_value='".$packages."' WHERE setting_key='packages'");
        echo json_encode(["code"=>0]);
        break;
    
    // Global settings
    case "settings":
        $r = $db->query("SELECT * FROM settings");
        $settings = [];
        while($x = $r->fetch_assoc()){
            $settings[$x["setting_key"]] = $x["setting_value"];
        }
        echo json_encode(["code"=>0,"data"=>$settings]);
        break;
    
    // Update global setting
    case "setting/update":
        $key = $_POST["key"] ?? "";
        $value = $_POST["value"] ?? "";
        
        if(!$key){
            echo json_encode(["code"=>400]);break;
        }
        
        $existing = $db->query("SELECT id FROM settings WHERE setting_key='".$key."'")->fetch_assoc();
        if($existing){
            $db->query("UPDATE settings SET setting_value='".$value."' WHERE setting_key='".$key."'");
        }else{
            $db->query("INSERT INTO settings (setting_key, setting_value) VALUES ('".$key."','".$value."')");
        }
        echo json_encode(["code"=>0]);
        break;
    
    // Platform stats
    case "stats":
        $merchants = $db->query("SELECT COUNT(*) as c FROM merchants")->fetch_assoc();
        $users = $db->query("SELECT COUNT(*) as c FROM users")->fetch_assoc();
        $orders = $db->query("SELECT COUNT(*) as c FROM orders")->fetch_assoc();
        
        echo json_encode(["code"=>0,"data"=>[
            "total_merchants"=>intval($merchants["c"]),
            "total_users"=>intval($users["c"]),
            "total_orders"=>intval($orders["c"])
        ]]);
        break;
        
    default:
        echo json_encode(["code"=>404]);
}
