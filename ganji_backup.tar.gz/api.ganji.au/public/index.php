<?php
header("Content-Type: application/json");
require_once __DIR__."/../config/database.php";
$db = new mysqli(DB_HOST,DB_USER,DB_PASS,DB_NAME);
$db->set_charset("utf8mb4");

$action = $_GET["action"] ?? "";
$public = ["config/fee","merchant_login","merchant_register","user_login","user_register","admin/tickets","ticket/reply","products","payment/types","categories","banners","reviews"];

$tok = $_SERVER["HTTP_AUTHORIZATION"] ?? "";
$auth = !empty($tok);
if(!in_array($action,$public) && !$auth){
    echo json_encode(["code"=>401,"msg"=>"Unauthorized"]);
    exit;
}

$mid = 0;
$uid = 0;
if($auth){
    $t = json_decode(base64_decode(str_replace("Bearer ","",$tok)),true);
    $mid = intval($t["merchant_id"] ?? 0);
    $uid = intval($t["user_id"] ?? 0);
}

switch($action){
    case "config/fee":
        echo json_encode(["code"=>0,"data"=>["basic"=>299,"pro"=>599,"enterprise"=>999]]);
        break;
    
    case "merchant_login":
        $u = $_POST["username"] ?? "";
        $p = $_POST["password"] ?? "";
        $s = $db->prepare("SELECT * FROM merchants WHERE username=?");
        $s->bind_param("s",$u);
        $s->execute();
        $r = $s->get_result();
        if($row = $r->fetch_assoc()){
            if(password_verify($p,$row["password"])){
                $token = base64_encode(json_encode(["merchant_id"=>$row["id"],"time"=>time()]));
                echo json_encode(["code"=>0,"data"=>["token"=>$token,"merchant"=>$row]]);
            }else{echo json_encode(["code"=>401,"msg"=>"Invalid password"]);}
        }else{echo json_encode(["code"=>401,"msg"=>"Merchant not found"]);}
        break;
        
    case "merchant_register":
        $u = $_POST["username"] ?? "";
        $p = $_POST["password"] ?? "";
        $n = $_POST["merchant_name"] ?? "";
        if(!$u || !$p || !$n){echo json_encode(["code"=>400,"msg"=>"Missing required"]);break;}
        $invite = strtoupper(substr(md5(uniqid()),0,8));
        $pwd = password_hash($p,PASSWORD_DEFAULT);
        $pkg = $_POST["package_type"] ?? "basic";
        $db->query("INSERT INTO merchants (username,password,merchant_name,invite_code,package_type) VALUES (\"$u\",\"$pwd\",\"$n\",\"$invite\",\"$pkg\")");
        echo json_encode(["code"=>0,"data"=>["id"=>$db->insert_id,"invite_code"=>$invite]]);
        break;

    case "user_login":
        $ph = $_POST["phone"] ?? "";
        $p = $_POST["password"] ?? "";
        $s = $db->prepare("SELECT * FROM users WHERE phone=?");
        $s->bind_param("s",$ph);
        $s->execute();
        $r = $s->get_result();
        if($row = $r->fetch_assoc()){
            if(password_verify($p,$row["password"])){
                $token = base64_encode(json_encode(["user_id"=>$row["id"],"merchant_id"=>$row["merchant_id"],"time"=>time()]));
                echo json_encode(["code"=>0,"data"=>["token"=>$token,"user"=>$row]]);
            }else{echo json_encode(["code"=>401,"msg"=>"Invalid password"]);}
        }else{echo json_encode(["code"=>401,"msg"=>"User not found"]);}
        break;
        
    case "user_register":
        $ph = $_POST["phone"] ?? "";
        $p = $_POST["password"] ?? "";
        $mid_post = intval($_POST["merchant_id"] ?? 1);
        if(!$ph || !$p){echo json_encode(["code"=>400,"msg"=>"Missing phone/password"]);break;}
        $check = $db->query("SELECT id FROM users WHERE phone=\"$ph\"")->fetch_assoc();
        if($check){echo json_encode(["code"=>400,"msg"=>"Phone already registered"]);break;}
        $pwd = password_hash($p,PASSWORD_DEFAULT);
        $db->query("INSERT INTO users (phone,password,merchant_id,nickname,status) VALUES (\"$ph\",\"$pwd\",$mid_post,\"$ph\",1)");
        $new_uid = $db->insert_id;
        $token = base64_encode(json_encode(["user_id"=>$new_uid,"merchant_id"=>$mid_post,"time"=>time()]));
        echo json_encode(["code"=>0,"data"=>["id"=>$new_uid,"token"=>$token]]);
        break;

    case "products":
        $m = $mid ?: intval($_GET["merchant_id"] ?? 1);
        $r = $db->query("SELECT * FROM products WHERE merchant_id=$m AND status=1 ORDER BY id DESC LIMIT 50");
        $list = [];
        while($x = $r->fetch_assoc()) $list[] = $x;
        echo json_encode(["code"=>0,"data"=>["list"=>$list]]);
        break;
        
    case "product/create":
        if(!$mid){echo json_encode(["code"=>401]);break;}
        $name = $_POST["name"] ?? "";
        $price = floatval($_POST["price"] ?? 0);
        if(!$name || !$price){echo json_encode(["code"=>400]);break;}
        $name_en = $_POST["name_en"] ?? "";
        $stock = intval($_POST["stock"] ?? 0);
        $desc = $_POST["description"] ?? "";
        $orig_price = floatval($_POST["original_price"] ?? 0);
        $cat_id = intval($_POST["category_id"] ?? 0);
        $cat_sql = $cat_id > 0 ? $cat_id : "NULL";
        $db->query("INSERT INTO products (merchant_id,name,name_en,description,price,original_price,stock,category_id,status) VALUES ($mid,\"$name\",\"$name_en\",\"$desc\",$price,$orig_price,$stock,$cat_sql,1)");
        echo json_encode(["code"=>0,"data"=>["id"=>$db->insert_id]]);
        break;
        
    case "product/update":
        if(!$mid){echo json_encode(["code"=>401]);break;}
        $id = intval($_POST["id"] ?? 0);
        $name = $_POST["name"] ?? "";
        $price = floatval($_POST["price"] ?? 0);
        $stock = intval($_POST["stock"] ?? 0);
        $db->query("UPDATE products SET name=\"$name\",price=$price,stock=$stock WHERE id=$id AND merchant_id=$mid");
        echo json_encode(["code"=>0]);
        break;
        
    case "product/delete":
        if(!$mid){echo json_encode(["code"=>401]);break;}
        $id = intval($_GET["id"] ?? 0);
        $db->query("DELETE FROM products WHERE id=$id AND merchant_id=$mid");
        echo json_encode(["code"=>0]);
        break;

    case "categories":
        $r = $db->query("SELECT * FROM categories WHERE (merchant_id=0 OR merchant_id=1 OR $mid>0) AND status=1");
        $list = [];
        while($x = $r->fetch_assoc()) $list[] = $x;
        echo json_encode(["code"=>0,"data"=>$list]);
        break;
        
    case "category/create":
        if(!$mid){echo json_encode(["code"=>401]);break;}
        $name = $_POST["name"] ?? "";
        if(!$name){echo json_encode(["code"=>400]);break;}
        $name_en = $_POST["name_en"] ?? "";
        $db->query("INSERT INTO categories (merchant_id,name,name_en,status) VALUES ($mid,\"$name\",\"$name_en\",1)");
        echo json_encode(["code"=>0,"data"=>["id"=>$db->insert_id]]);
        break;

    case "merchant/info":
        $r = $db->query("SELECT * FROM merchants WHERE id=$mid");
        $row = $r->fetch_assoc();
        echo json_encode($row ? ["code"=>0,"data"=>$row] : ["code"=>404]);
        break;
        
    case "merchant/stats":
        $o = intval($db->query("SELECT COUNT(*) c FROM orders WHERE (merchant_id=0 OR merchant_id=1 OR $mid>0)")->fetch_assoc()["c"] ?? 0);
        $p = intval($db->query("SELECT COUNT(*) c FROM products WHERE (merchant_id=0 OR merchant_id=1 OR $mid>0) AND status=1")->fetch_assoc()["c"] ?? 0);
        $u = intval($db->query("SELECT COUNT(*) c FROM users WHERE (merchant_id=0 OR merchant_id=1 OR $mid>0)")->fetch_assoc()["c"] ?? 0);
        $s = floatval($db->query("SELECT COALESCE(SUM(total_amount),0) t FROM orders WHERE (merchant_id=0 OR merchant_id=1 OR $mid>0) AND status=\"completed\"")->fetch_assoc()["t"] ?? 0);
        echo json_encode(["code"=>0,"data"=>["orders"=>$o,"products","payment/types"=>$p,"users"=>$u,"sales"=>$s]]);
        break;

    case "orders":
        $r = $db->query("SELECT o.*,u.nickname,u.phone FROM orders o LEFT JOIN users u ON o.user_id=u.id WHERE o.merchant_id=$mid ORDER BY o.id DESC LIMIT 50");
        $list = [];
        while($x = $r->fetch_assoc()) $list[] = $x;
        echo json_encode(["code"=>0,"data"=>["list"=>$list]]);
        break;
        
    case "order/update":
        if(!$mid){echo json_encode(["code"=>401]);break;}
        $id = intval($_POST["id"] ?? 0);
        $status = $_POST["status"] ?? "";
        $db->query("UPDATE orders SET status=\"$status\" WHERE id=$id AND merchant_id=$mid");
        echo json_encode(["code"=>0]);
        break;
        
    case "order/create":
        if(!$uid){echo json_encode(["code"=>401]);break;}
        $total = floatval($_POST["total_amount"] ?? 0);
        $items = $_POST["items"] ?? "[]";
        $no = "ORD".date("YmdHis").rand(1000,9999);
        $db->query("INSERT INTO orders (order_no,merchant_id,user_id,total_amount,status) VALUES (\"$no\",$mid,$uid,$total,\"pending\")");
        $order_id = $db->insert_id;
        $items_arr = json_decode($items,true) ?: [];
        foreach($items_arr as $item){
            $pid = intval($item["product_id"] ?? 0);
            $qty = intval($item["quantity"] ?? 1);
            $price = floatval($item["price"] ?? 0);
            $name = $item["name"] ?? "";
            $db->query("INSERT INTO order_items (order_id,product_id,product_name,price,quantity) VALUES ($order_id,$pid,\"$name\",$price,$qty)");
        }
        echo json_encode(["code"=>0,"data"=>["order_id"=>$order_id,"order_no"=>$no]]);
        break;

    case "customers":
        $r = $db->query("SELECT id,phone,nickname,merchant_id,status,created_at FROM users WHERE (merchant_id=0 OR merchant_id=1 OR $mid>0)");
        $list = [];
        while($x = $r->fetch_assoc()) $list[] = $x;
        echo json_encode(["code"=>0,"data"=>$list]);
        break;

    case "user/orders":
        $r = $db->query("SELECT * FROM orders WHERE user_id=$uid ORDER BY id DESC LIMIT 50");
        $list = [];
        while($x = $r->fetch_assoc()) $list[] = $x;
        echo json_encode(["code"=>0,"data"=>["list"=>$list]]);
        break;

    case "addresses":
        $r = $db->query("SELECT * FROM addresses WHERE user_id=$uid");
        $list = [];
        while($x = $r->fetch_assoc()) $list[] = $x;
        echo json_encode(["code"=>0,"data"=>$list]);
        break;
        
    case "address/create":
        if(!$uid){echo json_encode(["code"=>401]);break;}
        $m = $mid ?: 1;
        $name = $_POST["name"] ?? "";
        $phone = $_POST["phone"] ?? "";
        $province = $_POST["province"] ?? "";
        $city = $_POST["city"] ?? "";
        $district = $_POST["district"] ?? "";
        $detail = $_POST["detail"] ?? "";
        $is_default = intval($_POST["is_default"] ?? 0);
        if($is_default) $db->query("UPDATE addresses SET is_default=0 WHERE user_id=$uid");
        $db->query("INSERT INTO addresses (user_id,merchant_id,name,phone,province,city,district,detail,is_default) VALUES ($uid,$m,\"$name\",\"$phone\",\"$province\",\"$city\",\"$district\",\"$detail\",$is_default)");
        echo json_encode(["code"=>0,"data"=>["id"=>$db->insert_id]]);
        break;
        
    case "address/delete":
        if(!$uid){echo json_encode(["code"=>401]);break;}
        $id = intval($_GET["id"] ?? 0);
        $db->query("DELETE FROM addresses WHERE id=$id AND user_id=$uid");
        echo json_encode(["code"=>0]);
        break;

    case "cart":
        $r = $db->query("SELECT c.*,p.name,p.price,p.images FROM carts c LEFT JOIN products p ON c.product_id=p.id WHERE c.user_id=$uid");
        $list = [];
        while($x = $r->fetch_assoc()) $list[] = $x;
        echo json_encode(["code"=>0,"data"=>$list]);
        break;
        
    case "cart/add":
        if(!$uid){echo json_encode(["code"=>401]);break;}
        $m = $mid ?: 1;
        $pid = intval($_POST["product_id"] ?? 0);
        $qty = intval($_POST["quantity"] ?? 1);
        $ex = $db->query("SELECT id,quantity FROM carts WHERE user_id=$uid AND product_id=$pid")->fetch_assoc();
        if($ex){
            $new_qty = $ex["quantity"] + $qty;
            $db->query("UPDATE carts SET quantity=$new_qty WHERE id=".$ex["id"]);
        }else{
            $db->query("INSERT INTO carts (user_id,merchant_id,product_id,quantity) VALUES ($uid,$m,$pid,$qty)");
        }
        echo json_encode(["code"=>0]);
        break;
        
    case "cart/remove":
        if(!$uid){echo json_encode(["code"=>401]);break;}
        $id = intval($_GET["id"] ?? 0);
        $db->query("DELETE FROM carts WHERE id=$id AND user_id=$uid");
        echo json_encode(["code"=>0]);
        break;

    case "favorites":
        $r = $db->query("SELECT f.*,p.name,p.price,p.images FROM favorites f LEFT JOIN products p ON f.product_id=p.id WHERE f.user_id=$uid");
        $list = [];
        while($x = $r->fetch_assoc()) $list[] = $x;
        echo json_encode(["code"=>0,"data"=>$list]);
        break;
        
    case "favorite/add":
        if(!$uid){echo json_encode(["code"=>401]);break;}
        $pid = intval($_POST["product_id"] ?? 0);
        $db->query("INSERT IGNORE INTO favorites (user_id,product_id) VALUES ($uid,$pid)");
        echo json_encode(["code"=>0]);
        break;
        
    case "favorite/remove":
        if(!$uid){echo json_encode(["code"=>401]);break;}
        $id = intval($_GET["id"] ?? 0);
        $db->query("DELETE FROM favorites WHERE id=$id AND user_id=$uid");
        echo json_encode(["code"=>0]);
        break;

    case "reviews":
        $pid = intval($_GET["product_id"] ?? 0);
        $r = $db->query("SELECT r.*,u.nickname FROM reviews r LEFT JOIN users u ON r.user_id=u.id WHERE r.product_id=$pid ORDER BY r.id DESC");
        $list = [];
        while($x = $r->fetch_assoc()) $list[] = $x;
        echo json_encode(["code"=>0,"data"=>$list]);
        break;
        
    case "review/create":
        if(!$uid){echo json_encode(["code"=>401]);break;}
        $pid = intval($_POST["product_id"] ?? 0);
        $rating = intval($_POST["rating"] ?? 5);
        $content = $_POST["content"] ?? "";
        $db->query("INSERT INTO reviews (order_id,product_id,user_id,rating,content,status) VALUES (1,$pid,$uid,$rating,\"$content\",1)");
        echo json_encode(["code"=>0,"data"=>["id"=>$db->insert_id]]);
        break;

    case "order/delete":
        if(!$mid){echo json_encode(["code"=>401]);break;}
        $id = intval($_GET["id"] ?? 0);
        $db->query("DELETE FROM order_items WHERE order_id=$id");
        $db->query("DELETE FROM reviews WHERE order_id=$id");
        $db->query("DELETE FROM orders WHERE id=$id AND merchant_id=$mid");
        $db->query("DELETE FROM order_items WHERE order_id=$id");
        $db->query("DELETE FROM reviews WHERE order_id=$id");
        echo json_encode(["code"=>0]);
        break;

    case "banners":
        $r = $db->query("SELECT * FROM banners WHERE status=1 ORDER BY sort_order DESC");
        $list = [];
        while($x = $r->fetch_assoc()) $list[] = $x;
        echo json_encode(["code"=>0,"data"=>$list]);
        break;
    
    
    // Messages - Merchant view
    case "messages":
        $r = $db->query("SELECT * FROM messages WHERE (merchant_id=0 OR merchant_id=1 OR $mid>0) ORDER BY id DESC LIMIT 50");
        $list = [];
        while($x = $r->fetch_assoc()) $list[] = $x;
        echo json_encode(["code"=>0,"data"=>$list]);
        break;
    
    // Send message
    case "message/send":
        if(!$uid && !$mid){echo json_encode(["code"=>401]);break;}
        $content = $_POST["content"] ?? "";
        $type = $_POST["message_type"] ?? "text";
        $sender = $uid ? "user" : "merchant";
        $db->query("INSERT INTO messages (merchant_id,user_id,merchant_user_id,message_type,content,sender_type) VALUES ($mid,$uid,0,\"$type\",\"$content\",\"$sender\")");
        echo json_encode(["code"=>0,"data"=>["id"=>$db->insert_id]]);
        break;
    
    // User messages
    case "user/messages":
        $r = $db->query("SELECT * FROM messages WHERE user_id=$uid ORDER BY id DESC LIMIT 50");
        $list = [];
        while($x = $r->fetch_assoc()) $list[] = $x;
        echo json_encode(["code"=>0,"data"=>$list]);
        break;

    // Ticket - Merchant create
    case "ticket/create":
        if(!$mid){echo json_encode(["code"=>401]);break;}
        $title = $_POST["title"] ?? "";
        $desc = $_POST["description"] ?? "";
        $priority = $_POST["priority"] ?? "normal";
        if(!$title){echo json_encode(["code"=>400]);break;}
        $db->query("INSERT INTO tickets (merchant_id,title,description,priority,status) VALUES ($mid,\"$title\",\"$desc\",\"$priority\",\"pending\")");
        echo json_encode(["code"=>0,"data"=>["id"=>$db->insert_id]]);
        break;
    
    // Ticket - Merchant list
    case "tickets":
        $r = $db->query("SELECT * FROM tickets WHERE (merchant_id=0 OR merchant_id=1 OR $mid>0) ORDER BY id DESC LIMIT 50");
        $list = [];
        while($x = $r->fetch_assoc()) $list[] = $x;
        echo json_encode(["code"=>0,"data"=>$list]);
        break;
    
    // Ticket - Platform list
    case "admin/tickets":
        $r = $db->query("SELECT t.*,m.merchant_name FROM tickets t LEFT JOIN merchants m ON t.merchant_id=m.id ORDER BY t.id DESC LIMIT 50");
        $list = [];
        while($x = $r->fetch_assoc()) $list[] = $x;
        echo json_encode(["code"=>0,"data"=>$list]);
        break;
    
    // Ticket - Platform reply
    case "ticket/reply":
        if(!isset($_POST["admin_id"])){echo json_encode(["code"=>401]);break;}
        $id = intval($_POST["id"] ?? 0);
        $reply = $_POST["reply"] ?? "";
        $status = $_POST["status"] ?? "resolved";
        $admin_id = intval($_POST["admin_id"] ?? 1);
        $db->query("UPDATE tickets SET reply=\"$reply\",status=\"$status\",admin_id=$admin_id WHERE id=$id");
        echo json_encode(["code"=>0]);
        break;

    // Payment types
    case "payment/types":
        echo json_encode(["code"=>0,"data"=>[
            ["id"=>"alipay","name"=>"Alipay","name_en"=>"Alipay"],
            ["id"=>"wxpay","name"=>"WeChat Pay","name_en"=>"WeChat Pay"],
            ["id"=>"qqpay","name"=>"QQ Wallet","name_en"=>"QQ Wallet"],
            ["id"=>"bank","name"=>"Bank Card","name_en"=>"Bank Card"]
        ]]);
        break;

    // Payment create (Demo mode)
    case "payment/create":
        if(!$uid){echo json_encode(["code"=>401]);break;}
        $order_id = intval($_POST["order_id"] ?? 0);
        $order = $db->query("SELECT * FROM orders WHERE id=$order_id AND user_id=$uid")->fetch_assoc();
        if(!$order){echo json_encode(["code"=>404,"msg"=>"Order not found"]);break;}
        if($order["status"] == "paid"){echo json_encode(["code"=>400,"msg"=>"Already paid"]);break;}
        $db->query("UPDATE orders SET status='paid' WHERE id=$order_id");
        echo json_encode(["code"=>0,"data"=>["demo"=>true,"message"=>"Payment successful (Demo)"]]);
        break;
}

