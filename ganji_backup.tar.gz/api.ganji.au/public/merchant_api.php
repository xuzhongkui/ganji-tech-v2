<?php
header("Content-Type: application/json");
require_once __DIR__."/../config/database.php";
$db = new mysqli(DB_HOST,DB_USER,DB_PASS,DB_NAME);
$db->set_charset("utf8mb4");

$action = $_GET["action"] ?? "";

// Get token and merchant_id
$tok = $_SERVER["HTTP_AUTHORIZATION"] ?? "";
$mid = 0;
$uid = 0;
if($tok){
    $t = json_decode(base64_decode(str_replace("Bearer ","",$tok)),true);
    $mid = intval($t["merchant_id"] ?? 0);
    $uid = intval($t["user_id"] ?? 0);
}

switch($action){
    // Generate invite code
    case "generate":
        if(!$mid){
            echo json_encode(["code"=>401]);break;
        }
        $new_code = strtoupper(substr(md5(uniqid()),0,8));
        // Save invite code to merchant
        $db->query("UPDATE merchants SET invite_code='".$new_code."' WHERE id=".$mid);
        echo json_encode(["code"=>0,"data"=>["invite_code"=>$new_code]]);
        break;
    
    // Get merchant info by invite code (for user binding)
    case "info":
        $code = $_GET["invite_code"] ?? "";
        if(!$code){
            echo json_encode(["code"=>400,"msg"=>"Missing invite_code"]);break;
        }
        $m = $db->query("SELECT id,merchant_name,logo FROM merchants WHERE invite_code='".$code."'")->fetch_assoc();
        if(!$m){
            echo json_encode(["code"=>404,"msg"=>"Invalid invite code"]);break;
        }
        echo json_encode(["code"=>0,"data"=>$m]);
        break;
    
    // Get merchant stats
    case "stats":
        if(!$mid){
            echo json_encode(["code"=>401]);break;
        }
        $orders = $db->query("SELECT COUNT(*) as c FROM orders WHERE merchant_id=".$mid)->fetch_assoc();
        $products = $db->query("SELECT COUNT(*) as c FROM products WHERE merchant_id=".$mid)->fetch_assoc();
        $users = $db->query("SELECT COUNT(*) as c FROM users WHERE merchant_id=".$mid)->fetch_assoc();
        $sales = $db->query("SELECT SUM(total_amount) as s FROM orders WHERE merchant_id=".$mid." AND status='paid'")->fetch_assoc();
        echo json_encode(["code"=>0,"data"=>[
            "orders"=>intval($orders["c"]),
            "products"=>intval($products["c"]),
            "users"=>intval($users["c"]),
            "sales"=>floatval($sales["s"] ?: 0)
        ]]);
        break;
        
    default:
        echo json_encode(["code"=>404,"msg"=>"Action not found"]);
}
