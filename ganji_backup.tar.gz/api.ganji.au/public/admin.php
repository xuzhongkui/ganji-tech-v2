<?php
header("Content-Type: application/json");
require_once __DIR__."/../config/database.php";
$db = new mysqli(DB_HOST,DB_USER,DB_PASS,DB_NAME);
$db->set_charset("utf8mb4");

$action = $_GET["action"] ?? "";

switch($action){
    case "login":
        $username = $_POST["username"] ?? "";
        $password = $_POST["password"] ?? "";
        $admin = $db->query("SELECT * FROM admins WHERE username='".$username."'")->fetch_assoc();
        if(!$admin || !password_verify($password, $admin["password"])){
            echo json_encode(["code"=>401,"msg"=>"Invalid credentials"]);
            break;
        }
        $token = base64_encode(json_encode(["admin_id"=>$admin["id"],"role"=>$admin["role"],"time"=>time()]));
        echo json_encode(["code"=>0,"data"=>["token"=>$token,"admin"=>$admin]]);
        break;
        
    case "tickets":
        $token = $_SERVER["HTTP_AUTHORIZATION"] ?? "";
        if(empty($token)){
            echo json_encode(["code"=>401]);break;
        }
        $t = json_decode(base64_decode(str_replace("Bearer ","",$token)),true);
        $admin_id = $t["admin_id"] ?? 0;
        if(!$admin_id){
            echo json_encode(["code"=>401]);break;
        }
        $r = $db->query("SELECT t.*,m.merchant_name FROM tickets t LEFT JOIN merchants m ON t.merchant_id=m.id ORDER BY t.id DESC LIMIT 50");
        $list = [];
        while($x = $r->fetch_assoc()) $list[] = $x;
        echo json_encode(["code"=>0,"data"=>$list]);
        break;
        
    case "reply":
        $token = $_SERVER["HTTP_AUTHORIZATION"] ?? "";
        if(empty($token)){
            echo json_encode(["code"=>401]);break;
        }
        $t = json_decode(base64_decode(str_replace("Bearer ","",$token)),true);
        $admin_id = $t["admin_id"] ?? 0;
        if(!$admin_id){
            echo json_encode(["code"=>401]);break;
        }
        $id = intval($_POST["id"] ?? 0);
        $reply = $_POST["reply"] ?? "";
        $status = $_POST["status"] ?? "resolved";
        $db->query("UPDATE tickets SET reply='".$reply."',status='".$status."',admin_id=".$admin_id." WHERE id=".$id);
        echo json_encode(["code"=>0]);
        break;
        
    default:
        echo json_encode(["code"=>404,"msg"=>"Action not found"]);
}
