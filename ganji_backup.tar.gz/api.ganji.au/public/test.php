<?php echo 'PHP OK'; ?>
