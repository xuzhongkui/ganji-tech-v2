<?php
// CPayB Payment Configuration
// Sign up at https://cpayb.net

define('CPAYB_PID', '');        // Merchant ID
define('CPAYB_KEY', '');         // Merchant Key
define('CPAYB_URL', 'https://cpayb.net');  // Payment Gateway

// Payment types
define('PAY_ALIPAY', 'alipay');
define('PAY_WXPAY', 'wxpay');
define('PAY_QQPAY', 'qqpay');
define('PAY_BANK', 'bank');

/**
 * Generate payment signature
 */
function cpayb_sign(, ) {
    ksort();
     = '';
    foreach( as  => ) {
        if( == 'sign' ||  == 'sign_type' ||  === '') continue;
         .=  . '=' .  . '&';
    }
     .= 'key=' . ;
    return md5();
}

/**
 * Create payment URL (Page Redirect)
 */
function cpayb_submit(, , , , , , ,  = '',  = '') {
     = [
        'pid' => ,
        'type' => ,
        'out_trade_no' => ,
        'notify_url' => ,
        'return_url' => ,
        'name' => ,
        'money' => ,
        'param' => ,
        'sign_type' => 'MD5'
    ];
    ['sign'] = cpayb_sign(, );
    
     = CPAYB_URL . '/submit.php?' . http_build_query();
    return ;
}

/**
 * Get QR Code payment (API)
 */
function cpayb_api(, , , , , , , , ,  = '') {
     = [
        'pid' => ,
        'type' => ,
        'out_trade_no' => ,
        'notify_url' => ,
        'return_url' => ,
        'name' => ,
        'money' => ,
        'clientip' => ,
        'device' => 'pc',
        'param' => ,
        'sign_type' => 'MD5'
    ];
    ['sign'] = cpayb_sign(, );
    
     = curl_init();
    curl_setopt(, CURLOPT_URL, CPAYB_URL . '/mapi.php');
    curl_setopt(, CURLOPT_POST, true);
    curl_setopt(, CURLOPT_POSTFIELDS, http_build_query());
    curl_setopt(, CURLOPT_RETURNTRANSFER, true);
    curl_setopt(, CURLOPT_SSL_VERIFYPEER, false);
     = curl_exec();
    curl_close();
    
    return json_decode(, true);
}

/**
 * Verify payment notification
 */
function cpayb_notify_verify() {
     = ;
    if(!isset(['sign'])) return false;
    
     = ['sign'];
    unset(['sign']);
    
    return cpayb_sign(, ) === ;
}
