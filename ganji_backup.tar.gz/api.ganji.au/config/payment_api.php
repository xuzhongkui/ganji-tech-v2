<?php
// Add to switch statement in index.php

// Payment types
case payment/types:
    echo json_encode(["code"=>0,"data"=>[
        ["id"=>"alipay","name"=>"Alipay","name_en"=>"Alipay"],
        ["id"=>"wxpay","name"=>"WeChat Pay","name_en"=>"WeChat Pay"],
        ["id"=>"qqpay","name"=>"QQ Wallet","name_en"=>"QQ Wallet"],
        ["id"=>"bank","name"=>"Bank Card","name_en"=>"Bank Card"]
    ]]);
    break;

// Payment create (Demo)
case "payment/create":
    if(!){echo json_encode(["code"=>401]);break;}
     = intval(["order_id"] ?? 0);
     = ->query("SELECT * FROM orders WHERE id= AND user_id=")->fetch_assoc();
    if(!){echo json_encode(["code"=>404,"msg"=>"Order not found"]);break;}
    if(["status"] == "paid"){echo json_encode(["code"=>400,"msg"=>"Already paid"]);break;}
    ->query("UPDATE orders SET status='paid' WHERE id=");
    echo json_encode(["code"=>0,"data"=>["demo"=>true,"message"=>"Payment successful (Demo)"]]);
    break;
