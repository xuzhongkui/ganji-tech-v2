<?php
define("DB_HOST", "localhost");
define("DB_USER", "root");
define("DB_PASS", "940a32e42d54d272");
define("DB_NAME", "ganji_tech");

