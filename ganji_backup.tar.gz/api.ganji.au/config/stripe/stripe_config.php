<?php
/**
 * Stripe Connect Configuration
 * 
 * 使用说明:
 * 1. 在 Stripe Dashboard 创建 Connect 平台账户
 * 2. 获取 Secret Key 和 Publishable Key
 * 3. 配置 below
 */

return [
    // Stripe API Keys (从 Stripe Dashboard 获取)
    'secret_key' => getenv('STRIPE_SECRET_KEY') ?: 'sk_test_xxxxx',
    'publishable_key' => getenv('STRIPE_PUBLISHABLE_KEY') ?: 'pk_test_xxxxx',
    
    // Webhook Secret (从 Stripe Dashboard 获取)
    'webhook_secret' => getenv('STRIPE_WEBHOOK_SECRET') ?: 'whsec_xxxxx',
    
    // 平台信息
    'platform_name' => 'GanjiTech',
    'platform_country' => 'AU',  // Australia
    
    // 商户收费设置
    'application_fee_percent' => 2.5,  // 平台收取 2.5% 手续费
    'application_fee_fixed' => 0.30,  // 固定费用 $0.30
    
    // 支持的货币
    'currency' => 'aud',
    
    // 回调URL
    'urls' => [
        'onboarding_return' => 'https://merchant.ganji.au/stripe/return',
        'onboarding_refresh' => 'https://merchant.ganji.au/stripe/refresh',
        'payment_success' => 'https://www.ganji.au/payment/success',
        'payment_cancel' => 'https://www.ganji.au/payment/cancel',
        'webhook' => 'https://api.ganji.au/stripe/webhook',
    ],
];
