<?php require_once __DIR__."/../../vendor/autoload.php"; ?>
<?php
/**
 * Stripe Connect Library
 * 
 * 支持:
 * - Express 商户账户创建
 * - 支付处理 (Destination/Direct Charges)
 * - 手续费扣除
 * - Webhooks 处理
 */

require_once __DIR__ . '/stripe_config.php';

class StripeConnect {
    private $config;
    private $stripeApi;
    
    public function __construct() {
        $this->config = require __DIR__ . '/stripe_config.php';
        
        // 初始化 Stripe
        \Stripe\Stripe::setApiKey($this->config['secret_key']);
    }
    
    /**
     * 创建商户 Express 账户
     * 
     * @param string $email 商户邮箱
     * @param string $businessName 商户名称
     * @return array ['account_id' => 'acct_xxx', 'onboarding_url' => 'https://...']
     */
    public function createMerchantAccount($email, $businessName) {
        try {
            // 创建 Express 账户
            $account = \Stripe\Account::create([
                'type' => 'express',
                'country' => $this->config['platform_country'],
                'email' => $email,
                'capabilities' => [
                    'transfers' => ['requested' => true],
                ],
                'business_profile' => [
                    'name' => $businessName,
                ],
            ]);
            
            // 创建账户链接用于 onboarding
            $accountLink = \Stripe\AccountLink::create([
                'account' => $account->id,
                'refresh_url' => $this->config['urls']['onboarding_refresh'] . '?account=' . $account->id,
                'return_url' => $this->config['urls']['onboarding_return'] . '?account=' . $account->id,
                'type' => 'account_onboarding',
            ]);
            
            return [
                'success' => true,
                'account_id' => $account->id,
                'onboarding_url' => $accountLink->url,
            ];
            
        } catch (\Exception $e) {
            return [
                'success' => false,
                'error' => $e->getMessage(),
            ];
        }
    }
    
    /**
     * 检查商户账户状态
     */
    public function getAccountStatus($accountId) {
        try {
            $account = \Stripe\Account::retrieve($accountId);
            
            return [
                'success' => true,
                'id' => $account->id,
                'charges_enabled' => $account->charges_enabled,
                'payouts_enabled' => $account->payouts_enabled,
                'details_submitted' => $account->details_submitted,
                'requirements' => $account->requirements,
            ];
            
        } catch (\Exception $e) {
            return [
                'success' => false,
                'error' => $e->getMessage(),
            ];
        }
    }
    
    /**
     * 重新生成 Onboarding 链接
     */
    public function refreshOnboarding($accountId) {
        try {
            $accountLink = \Stripe\AccountLink::create([
                'account' => $accountId,
                'refresh_url' => $this->config['urls']['onboarding_refresh'] . '?account=' . $accountId,
                'return_url' => $this->config['urls']['onboarding_return'] . '?account=' . $accountId,
                'type' => 'account_onboarding',
            ]);
            
            return [
                'success' => true,
                'url' => $accountLink->url,
            ];
            
        } catch (\Exception $e) {
            return [
                'success' => false,
                'error' => $e->getMessage(),
            ];
        }
    }
    
    /**
     * 创建支付 (Destination Charges - 推荐)
     * 
     * 资金流程:
     * 1. 顾客付款到平台
     * 2. 平台扣除手续费
     * 3. 余款转给商户
     * 
     * @param float $amount 金额 (分)
     * @param string $currency 货币
     * @param string $merchantAccountId 商户Stripe账户ID
     * @param string $description 描述
     * @param array $metadata 元数据
     * @return array
     */
    public function createPayment($amount, $merchantAccountId, $description = '', $metadata = []) {
        try {
            // 计算平台手续费
            $feePercent = $this->config['application_fee_percent'];
            $feeFixed = $this->config['application_fee_fixed'] * 100; // 转为分
            $applicationFee = (int) round($amount * $feePercent / 100) + $feeFixed;
            
            // 创建 PaymentIntent
            $paymentIntent = \Stripe\PaymentIntent::create([
                'amount' => $amount,
                'currency' => $this->config['currency'],
                'payment_method_types' => ['card'],
                'transfer_data' => [
                    'destination' => $merchantAccountId,
                ],
                'application_fee_amount' => $applicationFee,
                'description' => $description,
                'metadata' => array_merge($metadata, [
                    'merchant_account' => $merchantAccountId,
                    'platform' => $this->config['platform_name'],
                ]),
            ]);
            
            return [
                'success' => true,
                'payment_intent_id' => $paymentIntent->id,
                'client_secret' => $paymentIntent->client_secret,
                'amount' => $amount,
                'application_fee' => $applicationFee,
                'status' => $paymentIntent->status,
            ];
            
        } catch (\Exception $e) {
            return [
                'success' => false,
                'error' => $e->getMessage(),
            ];
        }
    }
    
    /**
     * 创建支付链接 (Checkout Session)
     * 适合页面跳转支付
     */
    public function createCheckoutSession($amount, $merchantAccountId, $orderId, $customerEmail = null) {
        try {
            $feePercent = $this->config['application_fee_percent'];
            $feeFixed = $this->config['application_fee_fixed'] * 100;
            $applicationFee = (int) round($amount * $feePercent / 100) + $feeFixed;
            
            $sessionParams = [
                'payment_method_types' => ['card'],
                'line_items' => [[
                    'price_data' => [
                        'currency' => $this->config['currency'],
                        'product_data' => [
                            'name' => 'Order #' . $orderId,
                        ],
                        'unit_amount' => $amount,
                    ],
                    'quantity' => 1,
                ]],
                'mode' => 'payment',
                'payment_intent_data' => [
                    'application_fee_amount' => $applicationFee,
                    'transfer_data' => [
                        'destination' => $merchantAccountId,
                    ],
                    'metadata' => [
                        'order_id' => $orderId,
                        'merchant_account' => $merchantAccountId,
                    ],
                ],
                'success_url' => $this->config['urls']['payment_success'] . '?session_id={CHECKOUT_SESSION_ID}',
                'cancel_url' => $this->config['urls']['payment_cancel'],
                'metadata' => [
                    'order_id' => $orderId,
                    'merchant_account' => $merchantAccountId,
                ],
            ];
            
            if ($customerEmail) {
                $sessionParams['customer_email'] = $customerEmail;
            }
            
            $session = \Stripe\Checkout\Session::create($sessionParams);
            
            return [
                'success' => true,
                'session_id' => $session->id,
                'checkout_url' => $session->url,
            ];
            
        } catch (\Exception $e) {
            return [
                'success' => false,
                'error' => $e->getMessage(),
            ];
        }
    }
    
    /**
     * 获取支付状态
     */
    public function getPaymentStatus($paymentIntentId) {
        try {
            $paymentIntent = \Stripe\PaymentIntent::retrieve($paymentIntentId);
            
            return [
                'success' => true,
                'status' => $paymentIntent->status,
                'amount' => $paymentIntent->amount,
                'captured' => $paymentIntent->captured,
            ];
            
        } catch (\Exception $e) {
            return [
                'success' => false,
                'error' => $e->getMessage(),
            ];
        }
    }
    
    /**
     * 处理 Webhook
     */
    public function handleWebhook($payload, $sigHeader) {
        try {
            $event = \Stripe\Webhook::constructEvent(
                $payload,
                $sigHeader,
                $this->config['webhook_secret']
            );
            
            switch ($event->type) {
                case 'payment_intent.succeeded':
                    return $this->handlePaymentSuccess($event->data->object);
                    
                case 'payment_intent.payment_failed':
                    return $this->handlePaymentFailed($event->data->object);
                    
                case 'account.updated':
                    return $this->handleAccountUpdated($event->data->object);
                    
                case 'transfer.created':
                    return $this->handleTransferCreated($event->data->object);
                    
                default:
                    return ['success' => true, 'handled' => false];
            }
            
        } catch (\Exception $e) {
            return [
                'success' => false,
                'error' => $e->getMessage(),
            ];
        }
    }
    
    private function handlePaymentSuccess($paymentIntent) {
        // 在这里处理支付成功逻辑
        // 例如: 更新订单状态、发送确认邮件等
        return [
            'success' => true,
            'event' => 'payment_intent.succeeded',
            'payment_id' => $paymentIntent->id,
            'amount' => $paymentIntent->amount,
            'metadata' => $paymentIntent->metadata,
        ];
    }
    
    private function handlePaymentFailed($paymentIntent) {
        return [
            'success' => true,
            'event' => 'payment_intent.payment_failed',
            'payment_id' => $paymentIntent->id,
        ];
    }
    
    private function handleAccountUpdated($account) {
        return [
            'success' => true,
            'event' => 'account.updated',
            'account_id' => $account->id,
        ];
    }
    
    private function handleTransferCreated($transfer) {
        return [
            'success' => true,
            'event' => 'transfer.created',
            'transfer_id' => $transfer->id,
            'amount' => $transfer->amount,
        ];
    }
    
    /**
     * 获取商户余额
     */
    public function getAccountBalance($accountId) {
        try {
            $balance = \Stripe\Balance::retrieve([
                'stripe_account' => $accountId,
            ]);
            
            return [
                'success' => true,
                'available' => $balance->available,
                'pending' => $balance->pending,
            ];
            
        } catch (\Exception $e) {
            return [
                'success' => false,
                'error' => $e->getMessage(),
            ];
        }
    }
    
    /**
     * 创建 Payout
     */
    public function createPayout($accountId, $amount) {
        try {
            $payout = \Stripe\Payout::create([
                'amount' => $amount,
                'currency' => $this->config['currency'],
            ], [
                'stripe_account' => $accountId,
            ]);
            
            return [
                'success' => true,
                'payout_id' => $payout->id,
                'status' => $payout->status,
            ];
            
        } catch (\Exception $e) {
            return [
                'success' => false,
                'error' => $e->getMessage(),
            ];
        }
    }
}
