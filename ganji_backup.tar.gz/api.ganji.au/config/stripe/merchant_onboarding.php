<?php
/**
 * Stripe Connect 商户入驻流程
 * 
 * 商户注册后自动创建Stripe账户并返回入驻链接
 */

require_once __DIR__ . '/../config/stripe/stripe_connect.php';

class MerchantOnboarding {
    private $stripe;
    
    public function __construct() {
        $this->stripe = new StripeConnect();
    }
    
    /**
     * 为商户创建Stripe Connect账户
     * 
     * @param int $merchantId 商户ID
     * @param string $email 商户邮箱
     * @param string $businessName 商户名称
     * @return array
     */
    public function createAccount($merchantId, $email, $businessName) {
        // 1. 创建Stripe Express账户
        $result = $this->stripe->createMerchantAccount($email, $businessName);
        
        if (!$result['success']) {
            return [
                'success' => false,
                'error' => $result['error']
            ];
        }
        
        // 2. 保存 account_id 到数据库 (需要根据你的数据库结构修改)
        $this->saveStripeAccountId($merchantId, $result['account_id']);
        
        return [
            'success' => true,
            'account_id' => $result['account_id'],
            'onboarding_url' => $result['onboarding_url']
        ];
    }
    
    /**
     * 获取商户的Stripe状态
     */
    public function getAccountStatus($merchantId) {
        $accountId = $this->getStripeAccountId($merchantId);
        
        if (!$accountId) {
            return [
                'success' => false,
                'error' => '商户未开通Stripe'
            ];
        }
        
        return $this->stripe->getAccountStatus($accountId);
    }
    
    /**
     * 重新生成入驻链接
     */
    public function refreshOnboarding($merchantId) {
        $accountId = $this->getStripeAccountId($merchantId);
        
        if (!$accountId) {
            return [
                'success' => false,
                'error' => '商户未开通Stripe'
            ];
        }
        
        return $this->stripe->refreshOnboarding($accountId);
    }
    
    /**
     * 检查商户是否完成入驻
     */
    public function isOnboardingComplete($merchantId) {
        $status = $this->getAccountStatus($merchantId);
        
        if (!$status['success']) {
            return false;
        }
        
        // charges_enabled = 可以收款
        // payouts_enabled = 可以提现
        return $status['charges_enabled'] ?? false;
    }
    
    /**
     * 保存Stripe账户ID到数据库
     * 根据你的数据库结构修改
     */
    private function saveStripeAccountId($merchantId, $accountId) {
        // 示例: 根据你的数据库修改
        // $pdo = new PDO(...);
        // $stmt = $pdo->prepare("UPDATE merchants SET stripe_account_id = ? WHERE id = ?");
        // $stmt->execute([$accountId, $merchantId]);
        
        // 临时保存到文件 (测试用)
        $file = __DIR__ . '/merchant_stripe_ids.json';
        $data = file_exists($file) ? json_decode(file_get_contents($file), true) : [];
        $data[$merchantId] = $accountId;
        file_put_contents($file, json_encode($data, JSON_PRETTY_PRINT));
    }
    
    /**
     * 从数据库获取Stripe账户ID
     */
    private function getStripeAccountId($merchantId) {
        $file = __DIR__ . '/merchant_stripe_ids.json';
        if (!file_exists($file)) {
            return null;
        }
        
        $data = json_decode(file_get_contents($file), true);
        return $data[$merchantId] ?? null;
    }
}

/**
 * 商户注册后的回调处理
 * 在商户注册成功后调用此函数
 */
function onMerchantRegistered($merchantId, $email, $businessName) {
    $onboarding = new MerchantOnboarding();
    
    $result = $onboarding->createAccount($merchantId, $email, $businessName);
    
    if ($result['success']) {
        // 返回入驻链接给商户
        return [
            'success' => true,
            'stripe_onboarding_url' => $result['onboarding_url'],
            'message' => '请完成Stripe入驻以接受付款'
        ];
    } else {
        return [
            'success' => false,
            'error' => 'Stripe账户创建失败: ' . $result['error']
        ];
    }
}
