<?php
/**
 * Stripe Connect 商户入驻流程 (可选)
 * 
 * 商户可以跳过Stripe注册，之后再补充
 */

require_once __DIR__ . '/../config/stripe/stripe_connect.php';

class MerchantOnboarding {
    private $stripe;
    private $idsFile;
    
    public function __construct() {
        $this->stripe = new StripeConnect();
        $this->idsFile = __DIR__ . '/merchant_stripe_ids.json';
    }
    
    /**
     * 为商户创建Stripe Connect账户 (可选)
     */
    public function createAccount($merchantId, $email, $businessName) {
        $result = $this->stripe->createMerchantAccount($email, $businessName);
        
        if (!$result['success']) {
            return [
                'success' => false,
                'error' => $result['error']
            ];
        }
        
        $this->saveStripeAccountId($merchantId, $result['account_id']);
        
        return [
            'success' => true,
            'account_id' => $result['account_id'],
            'onboarding_url' => $result['onboarding_url']
        ];
    }
    
    /**
     * 跳过Stripe注册
     */
    public function skipOnboarding($merchantId, $reason = '') {
        // 记录跳过原因和时间
        $skipFile = __DIR__ . '/merchant_skipped.json';
        $data = file_exists($skipFile) ? json_decode(file_get_contents($skipFile), true) : [];
        $data[$merchantId] = [
            'skipped_at' => date('Y-m-d H:i:s'),
            'reason' => $reason
        ];
        file_put_contents($skipFile, json_encode($data, JSON_PRETTY_PRINT));
        
        return [
            'success' => true,
            'message' => '已跳过Stripe注册，您可以稍后在商户后台补充'
        ];
    }
    
    /**
     * 检查商户是否已开通Stripe
     */
    public function hasStripe($merchantId) {
        return $this->getStripeAccountId($merchantId) !== null;
    }
    
    /**
     * 检查是否跳过
     */
    public function hasSkipped($merchantId) {
        $skipFile = __DIR__ . '/merchant_skipped.json';
        if (!file_exists($skipFile)) return false;
        $data = json_decode(file_get_contents($skipFile), true);
        return isset($data[$merchantId]);
    }
    
    /**
     * 获取Stripe状态
     */
    public function getAccountStatus($merchantId) {
        $accountId = $this->getStripeAccountId($merchantId);
        
        if (!$accountId) {
            return [
                'success' => false,
                'error' => '商户未开通Stripe'
            ];
        }
        
        return $this->stripe->getAccountStatus($accountId);
    }
    
    /**
     * 重新生成入驻链接
     */
    public function refreshOnboarding($merchantId) {
        $accountId = $this->getStripeAccountId($merchantId);
        
        if (!$accountId) {
            return [
                'success' => false,
                'error' => '商户未开通Stripe'
            ];
        }
        
        return $this->stripe->refreshOnboarding($accountId);
    }
    
    /**
     * 是否可以收款
     */
    public function canReceivePayment($merchantId) {
        $status = $this->getAccountStatus($merchantId);
        
        if (!$status['success']) {
            return false;
        }
        
        return $status['charges_enabled'] ?? false;
    }
    
    /**
     * 获取未完成Stripe的商户列表 (用于提醒)
     */
    public function getMerchantsWithoutStripe($limit = 100) {
        // 读取所有商户 (需要根据实际数据库结构调整)
        $idsFile = __DIR__ . '/merchant_stripe_ids.json';
        $skippedFile = __DIR__ . '/merchant_skipped.json';
        
        $hasStripe = file_exists($idsFile) ? json_decode(file_get_contents($idsFile), true) : [];
        $skipped = file_exists($skippedFile) ? json_decode(file_get_contents($skippedFile), true) : [];
        
        return [
            'has_stripe' => array_keys($hasStripe),
            'skipped' => $skipped,
            'total_without_stripe' => count($skipped)
        ];
    }
    
    private function saveStripeAccountId($merchantId, $accountId) {
        $data = file_exists($this->idsFile) ? json_decode(file_get_contents($this->idsFile), true) : [];
        $data[$merchantId] = $accountId;
        file_put_contents($this->idsFile, json_encode($data, JSON_PRETTY_PRINT));
    }
    
    private function getStripeAccountId($merchantId) {
        if (!file_exists($this->idsFile)) {
            return null;
        }
        $data = json_decode(file_get_contents($this->idsFile), true);
        return $data[$merchantId] ?? null;
    }
}

/**
 * 商户注册后的处理 (可选Stripe)
 */
function onMerchantRegistered($merchantId, $email, $businessName, $skipStripe = false) {
    $onboarding = new MerchantOnboarding();
    
    if ($skipStripe) {
        // 跳过Stripe
        return $onboarding->skipOnboarding($merchantId, '商户注册时跳过');
    }
    
    // 创建Stripe账户
    return $onboarding->createAccount($merchantId, $email, $businessName);
}
